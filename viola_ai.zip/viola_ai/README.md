# 🎵 Viola AI - Open Source Music Generation Platform

**Viola AI** is a fully open-source, self-hosted alternative to Suno AI that generates music, separates stems, synthesizes vocals, and creates professional visual effects — all without API credits, subscriptions, or proprietary black boxes.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.1+-red.svg)](https://pytorch.org/)
[![CUDA](https://img.shields.io/badge/CUDA-11.8-green.svg)](https://developer.nvidia.com/cuda-downloads)

---

## ✨ Features

| Feature | Technology | Status |
|---------|-----------|--------|
| **AI Music Generation** (up to 5 min) | Meta MusicGen | ✅ Ready |
| **Stem Separation** (4-stem) | Meta Demucs v4 | ✅ Ready |
| **Vocal Extraction** | Demucs 2-stem | ✅ Ready |
| **Instrumental/Karaoke** | Demucs no-vocals | ✅ Ready |
| **Voice Synthesis** | StyleTTS2 | 🔄 Placeholder |
| **Voice Cloning** | RVC | 🔄 Placeholder |
| **Visual Effects** (6 presets) | Matplotlib + FFmpeg | ✅ Ready |
| **MIDI Export** | mido + librosa | ✅ Ready |
| **Lyrics Generation** | Template-based | ✅ Ready |
| **WebSocket Progress** | Real-time | ✅ Ready |
| **Async Processing** | Celery + Redis | ✅ Ready |
| **React Frontend** | Suno-style UI | ✅ Ready |

---

## 🚀 Quick Start

### Prerequisites
- **GPU**: NVIDIA GPU with 8GB+ VRAM (recommended)
- **CPU**: Works but slower (16GB+ RAM recommended)
- **OS**: Linux (Ubuntu 20.04+), macOS, or Windows WSL2
- **Software**: Python 3.10+, Node.js 18+, Redis, FFmpeg

### 1. Clone & Setup
```bash
git clone https://github.com/yourusername/viola-ai.git
cd viola-ai
chmod +x setup.sh
./setup.sh
```

### 2. Start Services
```bash
# Terminal 1: Redis
redis-server

# Terminal 2: Celery Worker
cd backend
celery -A tasks worker --loglevel=info --queues=generation,separation,voice,effects

# Terminal 3: API Server
python main.py

# Terminal 4: Frontend
cd ../frontend
npm start
```

### 3. Or Use Docker (Easiest)
```bash
docker-compose up -d
```

Access the app at **http://localhost:3000**

---

## 🎛️ API Endpoints

### Music Generation
```bash
# Quick generation (up to 60s)
POST /api/v1/generate/quick
Body: multipart/form-data
  - prompt: "lo-fi hip hop with rain"
  - duration: 30
  - style_tags: "lo-fi,chill"

# Long generation (up to 5 min, async)
POST /api/v1/generate
Body: JSON
  {
    "prompt": "epic orchestral soundtrack",
    "duration": 300,
    "style_tags": ["orchestral", "cinematic"],
    "cfg_scale": 7.0,
    "temperature": 1.0
  }

# Extend existing audio
POST /api/v1/extend
Body: multipart/form-data
  - audio_id: "gen_xxx"
  - extend_duration: 30
  - prompt: "Continue the melody"

# Remix with new style
POST /api/v1/remix
Body: multipart/form-data
  - audio_id: "gen_xxx"
  - style_prompt: "convert to jazz"
  - intensity: 0.5
```

### Stem Separation
```bash
# Quick separation (synchronous)
POST /api/v1/separate/quick
Body: multipart/form-data
  - file: <audio_file>
  - two_stems: "vocals"  # Optional: only vocals + no_vocals
  - model: "htdemucs_ft"   # htdemucs, htdemucs_ft, htdemucs_6s

# Async separation (for large files)
POST /api/v1/separate
Body: JSON
  {
    "audio_id": "gen_xxx",
    "stems": ["vocals", "drums", "bass", "other"],
    "model": "htdemucs_ft",
    "segment_length": 7
  }
```

### Voice Engine
```bash
# Text-to-speech
POST /api/v1/voice/synthesize
Body: multipart/form-data
  - text: "Hello world"
  - voice_id: "female_1"
  - emotion: "happy"
  - speed: 1.0

# Voice cloning (async)
POST /api/v1/voice/clone
Body: JSON
  {
    "voice_sample_id": "voice_xxx",
    "text": "This is my cloned voice",
    "emotion": "neutral",
    "speed": 1.0
  }
```

### Visual Effects
```bash
# Generate visual effect video
POST /api/v1/effects/generate
Body: JSON
  {
    "audio_id": "gen_xxx",
    "effect_type": "waveform",
    "resolution": "1920x1080",
    "color_scheme": "neon",
    "duration": 30
  }

# Get available presets
GET /api/v1/effects/presets
```

### Job Management
```bash
# Check job status
GET /api/v1/jobs/{job_id}

# WebSocket real-time progress
WS /ws/jobs/{job_id}

# Download audio
GET /api/v1/audio/{audio_id}
```

---

## 🖥️ CLI Usage

```bash
# Generate music
python cli.py generate "lo-fi hip hop with rain" --duration 120 --style "lo-fi,chill" --download

# Separate stems
python cli.py stems song.wav --two-stems vocals --download

# Generate visual effect
python cli.py visual song.wav --effect waveform --color neon

# Check server status
python cli.py status
```

---

## 🏗️ Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   React Frontend │────▶│  FastAPI Server │────▶│  Redis Queue    │
│   (Port 3000)    │     │   (Port 8000)   │     │   (Port 6379)   │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                               │                           │
                               ▼                           ▼
                        ┌──────────────┐           ┌──────────────┐
                        │  MusicGen    │           │   Celery     │
                        │  (GPU)       │           │   Workers    │
                        │  5-min gen   │           │   (GPU)      │
                        └──────────────┘           └──────────────┘
                        ┌──────────────┐                  │
                        │   Demucs     │                  │
                        │  Stem Split  │                  │
                        └──────────────┘                  │
                        ┌──────────────┐                  │
                        │   RVC/       │                  │
                        │  StyleTTS2   │                  │
                        │  Voice Clone │                  │
                        └──────────────┘                  │
                        ┌──────────────┐                  │
                        │  Matplotlib  │◀─────────────────┘
                        │  + FFmpeg    │    Async Tasks
                        │  Visual FX   │
                        └──────────────┘
```

---

## 🎨 Visual Effects Presets

| Effect | Description | Best For |
|--------|-------------|----------|
| **Reactive Waveform** | Dynamic bars reacting to audio | EDM, Electronic |
| **3D Spectrogram** | Frequency spectrum with depth | Ambient, Cinematic |
| **Chroma Circle** | Musical pitch class visualization | Jazz, Classical |
| **Particle System** | Audio-reactive particle explosion | Trap, Dubstep |
| **Circular Spectrum** | Radial frequency bars with glow | Pop, Hip Hop |

Color Schemes: `neon`, `sunset`, `ocean`, `matrix`, `cyberpunk`

Resolutions: `1920x1080`, `1280x720`, `3840x2160`, `1080x1920` (vertical)

---

## 🎵 Music Generation Parameters

| Parameter | Range | Default | Description |
|-----------|-------|---------|-------------|
| `duration` | 5-300s | 30 | Track length (5 min max) |
| `cfg_scale` | 1.0-20.0 | 7.0 | Prompt adherence |
| `temperature` | 0.1-2.0 | 1.0 | Randomness |
| `top_k` | 1-1000 | 250 | Sampling diversity |
| `top_p` | 0.1-1.0 | 0.9 | Nucleus sampling |
| `bpm` | 40-250 | auto | Beats per minute |
| `key` | Any | auto | Musical key |

---

## 🛠️ Configuration

Edit `.env` file:

```env
# Server
HOST=0.0.0.0
PORT=8000
DEBUG=false

# Paths
OUTPUT_DIR=./outputs
UPLOAD_DIR=./uploads
MODEL_DIR=./models

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# Celery
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0

# GPU
CUDA_VISIBLE_DEVICES=0

# Limits
MAX_UPLOAD_SIZE=104857600  # 100MB
MAX_DURATION=300           # 5 minutes
```

---

## 📁 Project Structure

```
viola-ai/
├── backend/
│   ├── main.py                 # FastAPI application
│   ├── tasks.py                # Celery async tasks
│   ├── services/
│   │   ├── music_generator.py  # MusicGen 5-min generation
│   │   ├── stem_separator.py   # Demucs stem extraction
│   │   ├── voice_engine.py     # StyleTTS2 + RVC
│   │   ├── visual_effects.py   # Pro visual FX generation
│   │   ├── audio_processor.py  # Audio utilities
│   │   └── lyrics_engine.py   # Lyrics + MIDI export
│   ├── utils/
│   │   ├── config.py           # Settings
│   │   └── logger.py           # Logging
│   ├── requirements.txt
│   ├── Dockerfile
│   └── docker-compose.yml
├── frontend/
│   ├── src/
│   │   ├── App.js              # Main React app
│   │   ├── App.css             # Dark theme styles
│   │   ├── index.js
│   │   └── index.css
│   ├── public/
│   ├── package.json
│   └── Dockerfile
├── cli.py                      # Command line interface
├── setup.sh                    # Setup script
├── docker-compose.yml          # Full stack orchestration
└── README.md
```

---

## 🧪 Testing

```bash
# Backend tests
pytest backend/tests/

# Frontend tests
npm test

# Load testing
locust -f load_test.py
```

---

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details.

---

## 📜 License

This project is licensed under the **MIT License** — see [LICENSE](LICENSE) file.

**Open Source Components:**
- MusicGen (Meta) - MIT/Apache 2.0
- Demucs (Meta) - MIT
- StyleTTS2 - MIT
- RVC - MIT
- FastAPI - MIT
- React - MIT

---

## 🙏 Acknowledgments

- **Meta AI** for MusicGen and Demucs
- **Suno AI** for UI inspiration (not code)
- **Open source community** for making this possible

---

## 📬 Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/viola-ai/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/viola-ai/discussions)
- **Discord**: [Viola AI Community](https://discord.gg/viola-ai)

---

**Made with 💚 and open source AI**
