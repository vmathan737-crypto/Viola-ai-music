import React, { useState, useEffect, useRef, useCallback } from 'react';
import './App.css';

// Viola AI Frontend - Professional Music Generation Interface
// Inspired by Suno AI but built with open-source ethics

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';

function App() {
  const [activeTab, setActiveTab] = useState('create');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generatedTracks, setGeneratedTracks] = useState([]);
  const [currentTrack, setCurrentTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [duration, setDuration] = useState(30);
  const [styleTags, setStyleTags] = useState([]);
  const [selectedEffect, setSelectedEffect] = useState('waveform');
  const [colorScheme, setColorScheme] = useState('neon');
  const [stems, setStems] = useState({});
  const [isSeparating, setIsSeparating] = useState(false);
  const [ws, setWs] = useState(null);

  const audioRef = useRef(null);
  const wsRef = useRef(null);

  const styleOptions = [
    'Lo-Fi', 'Hip Hop', 'Electronic', 'Jazz', 'Rock', 'Pop',
    'Classical', 'Ambient', 'Cinematic', 'Folk', 'R&B', 'Metal',
    'Trap', 'House', 'Techno', 'Synthwave', 'Orchestral', 'Piano'
  ];

  const effectOptions = [
    { id: 'waveform', name: 'Reactive Waveform', icon: '〰️' },
    { id: 'spectrogram', name: '3D Spectrogram', icon: '📊' },
    { id: 'chromagram', name: 'Chroma Circle', icon: '🎯' },
    { id: 'particles', name: 'Particle System', icon: '✨' },
    { id: 'circular_spectrum', name: 'Circular Spectrum', icon: '⭕' }
  ];

  const colorOptions = ['neon', 'sunset', 'ocean', 'matrix', 'cyberpunk'];

  // WebSocket connection for real-time progress
  const connectWebSocket = useCallback((jobId) => {
    const websocket = new WebSocket(`${API_BASE.replace('http', 'ws')}/ws/jobs/${jobId}`);

    websocket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setGenerationProgress(data.progress);

      if (data.status === 'completed') {
        setIsGenerating(false);
        fetchTrackResult(jobId);
        websocket.close();
      } else if (data.status === 'failed') {
        setIsGenerating(false);
        alert('Generation failed: ' + data.message);
        websocket.close();
      }
    };

    websocket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    wsRef.current = websocket;
    setWs(websocket);
  }, []);

  const fetchTrackResult = async (jobId) => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/jobs/${jobId}`);
      const data = await response.json();

      if (data.result) {
        const newTrack = {
          id: data.result,
          url: `${API_BASE}/api/v1/audio/${data.result}`,
          prompt: prompt,
          duration: duration,
          createdAt: new Date().toISOString()
        };

        setGeneratedTracks(prev => [newTrack, ...prev]);
        setCurrentTrack(newTrack);
      }
    } catch (error) {
      console.error('Error fetching result:', error);
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setGenerationProgress(0);

    try {
      const response = await fetch(`${API_BASE}/api/v1/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt,
          duration: duration,
          style_tags: styleTags,
          cfg_scale: 7.0,
          temperature: 1.0
        })
      });

      const data = await response.json();

      if (data.job_id) {
        connectWebSocket(data.job_id);
      }
    } catch (error) {
      console.error('Generation error:', error);
      setIsGenerating(false);
    }
  };

  const handleQuickGenerate = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);

    try {
      const formData = new FormData();
      formData.append('prompt', prompt);
      formData.append('duration', Math.min(duration, 60));
      formData.append('style_tags', styleTags.join(','));

      const response = await fetch(`${API_BASE}/api/v1/generate/quick`, {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (data.audio_id) {
        const newTrack = {
          id: data.audio_id,
          url: data.url,
          prompt: prompt,
          duration: duration,
          createdAt: new Date().toISOString()
        };

        setGeneratedTracks(prev => [newTrack, ...prev]);
        setCurrentTrack(newTrack);
      }

      setIsGenerating(false);
    } catch (error) {
      console.error('Quick generation error:', error);
      setIsGenerating(false);
    }
  };

  const handleSeparateStems = async (trackId) => {
    setIsSeparating(true);

    try {
      const response = await fetch(`${API_BASE}/api/v1/separate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audio_id: trackId,
          stems: ['vocals', 'drums', 'bass', 'other']
        })
      });

      const data = await response.json();

      if (data.job_id) {
        // Poll for completion
        const checkInterval = setInterval(async () => {
          const statusRes = await fetch(`${API_BASE}/api/v1/jobs/${data.job_id}`);
          const status = await statusRes.json();

          if (status.status === 'completed') {
            clearInterval(checkInterval);
            setStems(status.result || {});
            setIsSeparating(false);
          } else if (status.status === 'failed') {
            clearInterval(checkInterval);
            setIsSeparating(false);
            alert('Stem separation failed');
          }
        }, 2000);
      }
    } catch (error) {
      console.error('Separation error:', error);
      setIsSeparating(false);
    }
  };

  const handleGenerateVisual = async (trackId) => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/effects/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audio_id: trackId,
          effect_type: selectedEffect,
          color_scheme: colorScheme,
          resolution: '1920x1080',
          duration: 30
        })
      });

      const data = await response.json();
      alert('Visual effect generation started! Check jobs for progress.');
    } catch (error) {
      console.error('Visual effect error:', error);
    }
  };

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleStyleTag = (tag) => {
    setStyleTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  return (
    <div className="viola-app">
      {/* Header */}
      <header className="viola-header">
        <div className="logo">
          <span className="logo-icon">🎵</span>
          <span className="logo-text">Viola AI</span>
        </div>
        <nav className="nav-tabs">
          <button 
            className={activeTab === 'create' ? 'active' : ''}
            onClick={() => setActiveTab('create')}
          >
            Create
          </button>
          <button 
            className={activeTab === 'library' ? 'active' : ''}
            onClick={() => setActiveTab('library')}
          >
            Library
          </button>
          <button 
            className={activeTab === 'stems' ? 'active' : ''}
            onClick={() => setActiveTab('stems')}
          >
            Stem Lab
          </button>
          <button 
            className={activeTab === 'effects' ? 'active' : ''}
            onClick={() => setActiveTab('effects')}
          >
            Visual FX
          </button>
        </nav>
        <div className="user-menu">
          <span className="credits">∞ Unlimited</span>
          <button className="settings-btn">⚙️</button>
        </div>
      </header>

      {/* Main Content */}
      <main className="viola-main">
        {activeTab === 'create' && (
          <div className="create-section">
            {/* Prompt Area */}
            <div className="prompt-container">
              <h2>What should Viola create?</h2>
              <div className="prompt-input-wrapper">
                <textarea
                  className="prompt-input"
                  placeholder="A melancholic piano ballad with soft female vocals, rain sounds, 120 BPM, C minor..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={3}
                />
                <button 
                  className="generate-btn"
                  onClick={duration > 60 ? handleGenerate : handleQuickGenerate}
                  disabled={isGenerating || !prompt.trim()}
                >
                  {isGenerating ? (
                    <span className="generating">
                      <span className="spinner"></span>
                      Generating... {generationProgress}%
                    </span>
                  ) : (
                    <>
                      <span className="btn-icon">▶️</span>
                      Generate {duration}s
                    </>
                  )}
                </button>
              </div>

              {/* Style Tags */}
              <div className="style-tags">
                <label>Style Tags:</label>
                <div className="tags-container">
                  {styleOptions.map(tag => (
                    <button
                      key={tag}
                      className={`tag ${styleTags.includes(tag) ? 'active' : ''}`}
                      onClick={() => toggleStyleTag(tag)}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              {/* Duration Slider */}
              <div className="duration-control">
                <label>Duration: {duration}s</label>
                <input
                  type="range"
                  min="5"
                  max="300"
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  className="duration-slider"
                />
                <div className="duration-markers">
                  <span>5s</span>
                  <span>1min</span>
                  <span>2min</span>
                  <span>3min</span>
                  <span>4min</span>
                  <span>5min</span>
                </div>
              </div>
            </div>

            {/* Current Track Player */}
            {currentTrack && (
              <div className="player-card">
                <div className="waveform-visual">
                  <div className="waveform-bars">
                    {Array.from({ length: 50 }).map((_, i) => (
                      <div 
                        key={i}
                        className="bar"
                        style={{
                          height: `${Math.random() * 80 + 20}%`,
                          animationDelay: `${i * 0.05}s`
                        }}
                      />
                    ))}
                  </div>
                </div>
                <div className="player-controls">
                  <button className="play-btn" onClick={togglePlay}>
                    {isPlaying ? '⏸️' : '▶️'}
                  </button>
                  <div className="track-info">
                    <span className="track-prompt">{currentTrack.prompt}</span>
                    <span className="track-meta">{currentTrack.duration}s • AI Generated</span>
                  </div>
                  <div className="track-actions">
                    <button onClick={() => handleSeparateStems(currentTrack.id)}>
                      🎚️ Stems
                    </button>
                    <button onClick={() => handleGenerateVisual(currentTrack.id)}>
                      🎬 Visual
                    </button>
                    <button>⬇️ Download</button>
                  </div>
                </div>
                <audio 
                  ref={audioRef}
                  src={currentTrack.url}
                  onEnded={() => setIsPlaying(false)}
                />
              </div>
            )}
          </div>
        )}

        {activeTab === 'library' && (
          <div className="library-section">
            <h2>Your Library</h2>
            <div className="tracks-grid">
              {generatedTracks.map(track => (
                <div key={track.id} className="track-card">
                  <div className="track-art">
                    <div className="art-placeholder">
                      <span>🎵</span>
                    </div>
                  </div>
                  <div className="track-details">
                    <p className="track-prompt">{track.prompt}</p>
                    <span className="track-duration">{track.duration}s</span>
                  </div>
                  <div className="track-actions">
                    <button onClick={() => setCurrentTrack(track)}>▶️ Play</button>
                    <button>⬇️</button>
                    <button>🎚️</button>
                  </div>
                </div>
              ))}
              {generatedTracks.length === 0 && (
                <div className="empty-state">
                  <span className="empty-icon">🎼</span>
                  <p>No tracks yet. Start creating!</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'stems' && (
          <div className="stems-section">
            <h2>Stem Separation Lab</h2>
            <div className="stem-upload">
              <div className="upload-zone">
                <span className="upload-icon">📁</span>
                <p>Drop audio file or click to upload</p>
                <input type="file" accept="audio/*" />
              </div>
            </div>

            {isSeparating && (
              <div className="separating-indicator">
                <span className="spinner"></span>
                <p>Separating stems with Demucs AI...</p>
              </div>
            )}

            {Object.keys(stems).length > 0 && (
              <div className="stems-result">
                <h3>Extracted Stems</h3>
                <div className="stems-grid">
                  {Object.entries(stems).map(([name, id]) => (
                    <div key={name} className="stem-card">
                      <div className="stem-icon">
                        {name === 'vocals' && '🎤'}
                        {name === 'drums' && '🥁'}
                        {name === 'bass' && '🎸'}
                        {name === 'other' && '🎹'}
                        {name === 'no_vocals' && '🎵'}
                      </div>
                      <span className="stem-name">{name}</span>
                      <audio controls src={`${API_BASE}/api/v1/audio/${id}`} />
                      <button className="download-stem">⬇️</button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'effects' && (
          <div className="effects-section">
            <h2>Visual Effects Studio</h2>
            <div className="effects-config">
              <div className="effect-selector">
                <label>Effect Type:</label>
                <div className="effect-cards">
                  {effectOptions.map(effect => (
                    <div 
                      key={effect.id}
                      className={`effect-card ${selectedEffect === effect.id ? 'active' : ''}`}
                      onClick={() => setSelectedEffect(effect.id)}
                    >
                      <span className="effect-icon">{effect.icon}</span>
                      <span className="effect-name">{effect.name}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="color-selector">
                <label>Color Scheme:</label>
                <div className="color-options">
                  {colorOptions.map(color => (
                    <button
                      key={color}
                      className={`color-btn ${color} ${colorScheme === color ? 'active' : ''}`}
                      onClick={() => setColorScheme(color)}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>

              <button 
                className="generate-effect-btn"
                disabled={!currentTrack}
                onClick={() => currentTrack && handleGenerateVisual(currentTrack.id)}
              >
                🎬 Generate Visual Effect
              </button>
            </div>

            <div className="effect-preview">
              <div className={`preview-placeholder ${colorScheme}`}>
                <span className="preview-text">
                  {selectedEffect === 'waveform' && '〰️ Reactive Waveform'}
                  {selectedEffect === 'spectrogram' && '📊 3D Spectrogram'}
                  {selectedEffect === 'chromagram' && '🎯 Chroma Circle'}
                  {selectedEffect === 'particles' && '✨ Particle System'}
                  {selectedEffect === 'circular_spectrum' && '⭕ Circular Spectrum'}
                </span>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="viola-footer">
        <p>🎵 Viola AI — Open Source Music Generation</p>
        <p className="tech-stack">Powered by MusicGen • Demucs • StyleTTS2 • MIT License</p>
      </footer>
    </div>
  );
}

export default App;
