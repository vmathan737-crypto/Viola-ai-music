#!/usr/bin/env python3
"""
Viola AI CLI - Command Line Interface for Music Generation
Usage: python cli.py generate "prompt" --duration 120 --style "lo-fi,jazz"
"""

import argparse
import asyncio
import json
import sys
from pathlib import Path
import requests
from tqdm import tqdm

API_BASE = "http://localhost:8000"

def check_server():
    """Check if Viola AI server is running."""
    try:
        response = requests.get(f"{API_BASE}/health", timeout=5)
        return response.status_code == 200
    except:
        return False

def generate_music(args):
    """Generate music from command line."""
    if not check_server():
        print("❌ Viola AI server is not running. Start it with: python main.py")
        sys.exit(1)

    print(f"🎵 Generating music: {args.prompt}")
    print(f"   Duration: {args.duration}s | Style: {args.style}")

    # Quick generation for short clips
    if args.duration <= 60:
        response = requests.post(
            f"{API_BASE}/api/v1/generate/quick",
            data={
                "prompt": args.prompt,
                "duration": args.duration,
                "style_tags": args.style
            }
        )

        if response.status_code == 200:
            data = response.json()
            print(f"✅ Generated: {data['audio_id']}")
            print(f"   URL: {API_BASE}{data['url']}")

            if args.download:
                download_file(f"{API_BASE}{data['url']}", f"{args.output}.wav")
        else:
            print(f"❌ Error: {response.text}")
    else:
        # Long generation via async job
        response = requests.post(
            f"{API_BASE}/api/v1/generate",
            json={
                "prompt": args.prompt,
                "duration": args.duration,
                "style_tags": args.style.split(",") if args.style else [],
                "cfg_scale": args.cfg,
                "temperature": args.temperature
            }
        )

        if response.status_code == 200:
            data = response.json()
            job_id = data["job_id"]
            print(f"⏳ Job queued: {job_id}")
            print(f"   WebSocket: {data['websocket_url']}")

            # Poll for completion
            print("   Waiting for generation...")
            with tqdm(total=100, desc="Progress") as pbar:
                while True:
                    status = requests.get(f"{API_BASE}/api/v1/jobs/{job_id}").json()
                    pbar.update(status.get("progress", 0) - pbar.n)

                    if status["status"] == "completed":
                        print(f"\n✅ Complete! Audio ID: {status['result']}")
                        break
                    elif status["status"] == "failed":
                        print(f"\n❌ Failed: {status.get('error')}")
                        break

                    asyncio.sleep(2)
        else:
            print(f"❌ Error: {response.text}")

def separate_stems(args):
    """Separate audio into stems."""
    if not check_server():
        print("❌ Server not running")
        sys.exit(1)

    print(f"🎚️ Separating stems from: {args.audio}")

    # Upload file first
    with open(args.audio, 'rb') as f:
        response = requests.post(
            f"{API_BASE}/api/v1/separate/quick",
            files={"file": f},
            data={"two_stems": args.two_stems, "model": args.model}
        )

    if response.status_code == 200:
        data = response.json()
        print("✅ Stems separated:")
        for stem, url in data["urls"].items():
            print(f"   {stem}: {API_BASE}{url}")

            if args.download:
                download_file(f"{API_BASE}{url}", f"{args.output}_{stem}.wav")
    else:
        print(f"❌ Error: {response.text}")

def generate_visual(args):
    """Generate visual effects."""
    if not check_server():
        print("❌ Server not running")
        sys.exit(1)

    print(f"🎬 Generating {args.effect} visual effect...")

    response = requests.post(
        f"{API_BASE}/api/v1/effects/generate",
        json={
            "audio_id": args.audio,
            "effect_type": args.effect,
            "color_scheme": args.color,
            "resolution": args.resolution,
            "duration": args.duration
        }
    )

    if response.status_code == 200:
        data = response.json()
        print(f"⏳ Job queued: {data['job_id']}")
    else:
        print(f"❌ Error: {response.text}")

def list_models(args):
    """List available models and their status."""
    if not check_server():
        print("❌ Server not running")
        sys.exit(1)

    response = requests.get(f"{API_BASE}/")
    data = response.json()

    print("🎵 Viola AI Status:")
    print(f"   Status: {data['status']}")
    print(f"   GPU: {data.get('gpu_name', 'CPU')}")
    print(f"   Models: {', '.join(data.get('models_loaded', []))}")

def download_file(url: str, output_path: str):
    """Download file with progress bar."""
    response = requests.get(url, stream=True)
    total_size = int(response.headers.get('content-length', 0))

    with open(output_path, 'wb') as f, tqdm(
        total=total_size, unit='B', unit_scale=True, desc=output_path
    ) as pbar:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
            pbar.update(len(chunk))

    print(f"   💾 Saved: {output_path}")

def main():
    parser = argparse.ArgumentParser(
        description="Viola AI CLI - Open Source Music Generation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate 30s lo-fi track
  python cli.py generate "lo-fi hip hop with rain sounds" --duration 30 --style "lo-fi"

  # Generate 5-minute cinematic piece
  python cli.py generate "epic orchestral soundtrack" --duration 300 --cfg 10

  # Separate stems from audio file
  python cli.py stems song.wav --two-stems vocals --output stems/

  # Generate visual effect
  python cli.py visual song.wav --effect waveform --color neon
        """
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Generate command
    gen_parser = subparsers.add_parser("generate", help="Generate AI music")
    gen_parser.add_argument("prompt", help="Music description prompt")
    gen_parser.add_argument("--duration", "-d", type=int, default=30, help="Duration in seconds (max 300)")
    gen_parser.add_argument("--style", "-s", default="", help="Style tags (comma-separated)")
    gen_parser.add_argument("--cfg", type=float, default=7.0, help="Classifier-free guidance scale")
    gen_parser.add_argument("--temperature", "-t", type=float, default=1.0, help="Generation temperature")
    gen_parser.add_argument("--output", "-o", default="output", help="Output filename")
    gen_parser.add_argument("--download", action="store_true", help="Download generated file")
    gen_parser.set_defaults(func=generate_music)

    # Stems command
    stems_parser = subparsers.add_parser("stems", help="Separate audio stems")
    stems_parser.add_argument("audio", help="Audio file path")
    stems_parser.add_argument("--two-stems", help="Extract only 2 stems (e.g., vocals)")
    stems_parser.add_argument("--model", default="htdemucs", help="Demucs model variant")
    stems_parser.add_argument("--output", "-o", default="stems", help="Output directory")
    stems_parser.add_argument("--download", action="store_true", help="Download stems")
    stems_parser.set_defaults(func=separate_stems)

    # Visual command
    visual_parser = subparsers.add_parser("visual", help="Generate visual effects")
    visual_parser.add_argument("audio", help="Audio file ID or path")
    visual_parser.add_argument("--effect", "-e", default="waveform", 
                             choices=["waveform", "spectrogram", "chromagram", "particles", "circular_spectrum"],
                             help="Effect type")
    visual_parser.add_argument("--color", "-c", default="neon", help="Color scheme")
    visual_parser.add_argument("--resolution", "-r", default="1920x1080", help="Output resolution")
    visual_parser.add_argument("--duration", "-d", type=int, default=30, help="Video duration")
    visual_parser.set_defaults(func=generate_visual)

    # Status command
    status_parser = subparsers.add_parser("status", help="Check server status")
    status_parser.set_defaults(func=list_models)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)

if __name__ == "__main__":
    main()
