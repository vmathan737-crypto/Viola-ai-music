"""
Demucs-based stem separation service.
Extracts vocals, drums, bass, and other instruments from mixed audio.
Supports 4-stem and 2-stem (karaoke) modes.
"""

import torch
import torchaudio
import numpy as np
from typing import Optional, Dict, List
from pathlib import Path
import tempfile
import subprocess
import os

from demucs import pretrained
from demucs.apply import apply_model
from demucs.audio import AudioFile, save_audio

class StemSeparator:
    """
    Open-source stem separation using Meta's Demucs.
    Supports htdemucs, htdemucs_ft, htdemucs_6s, and mdx models.
    """

    def __init__(self, device: str = "cuda", model_name: str = "htdemucs_ft"):
        self.device = device
        self.model_name = model_name
        self.sample_rate = 44100

        # Load model
        print(f"Loading Demucs model: {model_name}...")
        self.model = pretrained.get_model(model_name)
        self.model.to(device)
        self.model.eval()

        # Get model sources
        self.sources = self.model.sources
        print(f"✅ Demucs {model_name} loaded - Sources: {self.sources}")

    def separate(
        self,
        audio_data: Optional[bytes] = None,
        audio_path: Optional[str] = None,
        model_name: Optional[str] = None,
        two_stems: Optional[str] = None,
        segment_length: int = 7,
        shifts: int = 1,
        overlap: float = 0.25,
        mp3: bool = False,
        mp3_bitrate: int = 320
    ) -> Dict[str, torch.Tensor]:
        """
        Separate audio into stems.

        Args:
            audio_data: Raw audio bytes
            audio_path: Path to audio file
            model_name: Override default model
            two_stems: Extract only 2 stems (e.g., 'vocals' for karaoke)
            segment_length: Segment length in seconds (reduce if OOM)
            shifts: Number of random shifts for augmentation (slower but better)
            overlap: Overlap between segments (0.0-1.0)

        Returns:
            Dict mapping stem name to audio tensor [channels, samples]
        """
        # Load audio
        if audio_data:
            # Save to temp file
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                tmp.write(audio_data)
                tmp_path = tmp.name
            wav, sr = torchaudio.load(tmp_path)
            os.unlink(tmp_path)
        elif audio_path:
            wav, sr = torchaudio.load(audio_path)
        else:
            raise ValueError("Either audio_data or audio_path must be provided")

        # Resample if needed
        if sr != self.sample_rate:
            wav = torchaudio.functional.resample(wav, sr, self.sample_rate)

        # Ensure stereo
        if wav.shape[0] == 1:
            wav = wav.repeat(2, 1)

        # Add batch dimension
        wav = wav[None].to(self.device)

        # Use specified model or default
        model = self.model
        if model_name and model_name != self.model_name:
            model = pretrained.get_model(model_name)
            model.to(self.device)
            model.eval()

        # Apply separation
        with torch.no_grad():
            sources = apply_model(
                model,
                wav,
                segment=segment_length,
                shifts=shifts,
                overlap=overlap,
                split=True,
                progress=True
            )[0]  # Remove batch dim

        # Build result dict
        result = {}
        for i, source_name in enumerate(model.sources):
            result[source_name] = sources[i].cpu()

        # Handle two-stems mode
        if two_stems and two_stems in result:
            # Create "no_stem" by mixing all other sources
            other_sources = [s for name, s in result.items() if name != two_stems]
            no_stem = torch.stack(other_sources).sum(dim=0)

            return {
                two_stems: result[two_stems],
                f"no_{two_stems}": no_stem
            }

        return result

    def separate_batch(
        self,
        audio_paths: List[str],
        output_dir: str,
        model_name: Optional[str] = None,
        two_stems: Optional[str] = None,
        mp3: bool = False
    ) -> List[Dict[str, str]]:
        """
        Batch process multiple files.
        Returns list of dicts with stem file paths.
        """
        results = []

        for audio_path in audio_paths:
            stems = self.separate(
                audio_path=audio_path,
                model_name=model_name,
                two_stems=two_stems
            )

            # Save stems
            base_name = Path(audio_path).stem
            stem_paths = {}

            for stem_name, audio in stems.items():
                ext = "mp3" if mp3 else "wav"
                output_path = f"{output_dir}/{base_name}_{stem_name}.{ext}"

                if mp3:
                    # Use ffmpeg for MP3 encoding
                    temp_wav = f"{output_dir}/temp_{stem_name}.wav"
                    torchaudio.save(temp_wav, audio, self.sample_rate)
                    subprocess.run([
                        "ffmpeg", "-i", temp_wav, "-b:a", "320k",
                        "-y", output_path
                    ], capture_output=True)
                    os.remove(temp_wav)
                else:
                    torchaudio.save(output_path, audio, self.sample_rate)

                stem_paths[stem_name] = output_path

            results.append(stem_paths)

        return results

    def get_vocals(self, audio_data: bytes) -> torch.Tensor:
        """Quick vocal extraction."""
        result = self.separate(audio_data=audio_data, two_stems="vocals")
        return result["vocals"]

    def get_instrumental(self, audio_data: bytes) -> torch.Tensor:
        """Quick instrumental extraction (karaoke)."""
        result = self.separate(audio_data=audio_data, two_stems="vocals")
        return result["no_vocals"]

    def get_drums(self, audio_data: bytes) -> torch.Tensor:
        """Extract drum track."""
        result = self.separate(audio_data=audio_data)
        return result.get("drums", torch.zeros(2, 1))

    def get_bass(self, audio_data: bytes) -> torch.Tensor:
        """Extract bass track."""
        result = self.separate(audio_data=audio_data)
        return result.get("bass", torch.zeros(2, 1))

    def cleanup(self):
        """Free GPU memory."""
        del self.model
        torch.cuda.empty_cache()
