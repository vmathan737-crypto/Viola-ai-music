"""
Professional visual effects generation synced to audio.
Effects: waveform, spectrogram, chromagram, particle system, reactive mesh.
Uses matplotlib, manim, and custom shaders for pro output.
"""

import torch
import torchaudio
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, FancyBboxPatch
from matplotlib.collections import LineCollection
from matplotlib.colors import LinearSegmentedColormap
import cv2
from typing import Optional, Dict, List, Tuple
from pathlib import Path
import tempfile
import subprocess
import os
from scipy import signal
from scipy.ndimage import gaussian_filter1d

class VisualEffects:
    """
    Generate professional visual effects synced to audio.
    Output: MP4 video with audio, or image sequence.
    """

    def __init__(self, ffmpeg_path: str = "ffmpeg"):
        self.ffmpeg_path = ffmpeg_path
        self.fps = 30
        self.sample_rate = 44100

        # Color schemes
        self.color_schemes = {
            "neon": {
                "bg": "#0a0a0a",
                "primary": "#00ff88",
                "secondary": "#ff00ff",
                "accent": "#00ffff",
                "gradient": ["#00ff88", "#00ffff", "#ff00ff"]
            },
            "sunset": {
                "bg": "#1a0a2e",
                "primary": "#ff6b35",
                "secondary": "#f7931e",
                "accent": "#ffd700",
                "gradient": ["#ff6b35", "#f7931e", "#ffd700"]
            },
            "ocean": {
                "bg": "#001a33",
                "primary": "#00b4d8",
                "secondary": "#90e0ef",
                "accent": "#caf0f8",
                "gradient": ["#00b4d8", "#90e0ef", "#caf0f8"]
            },
            "matrix": {
                "bg": "#000000",
                "primary": "#00ff00",
                "secondary": "#008800",
                "accent": "#00cc00",
                "gradient": ["#00ff00", "#008800", "#00cc00"]
            },
            "cyberpunk": {
                "bg": "#0d0221",
                "primary": "#ff3864",
                "secondary": "#261447",
                "accent": "#f9c80e",
                "gradient": ["#ff3864", "#f9c80e", "#2de2e6"]
            }
        }

    def get_presets(self) -> Dict:
        """Return available effect presets."""
        return {
            "effects": [
                {
                    "id": "waveform",
                    "name": "Reactive Waveform",
                    "description": "Dynamic waveform bars reacting to audio amplitude",
                    "params": ["bar_count", "smoothing", "mirror_mode"]
                },
                {
                    "id": "spectrogram",
                    "name": "3D Spectrogram",
                    "description": "Frequency spectrum visualization with depth",
                    "params": ["freq_range", "resolution", "perspective"]
                },
                {
                    "id": "chromagram",
                    "name": "Chroma Circle",
                    "description": "Musical pitch class visualization in circular form",
                    "params": ["ring_count", "rotation_speed", "glow_intensity"]
                },
                {
                    "id": "particles",
                    "name": "Particle System",
                    "description": "Audio-reactive particle explosion",
                    "params": ["particle_count", "physics", "trail_length"]
                },
                {
                    "id": "reactive_mesh",
                    "name": "Reactive Mesh",
                    "description": "3D wireframe mesh deformed by audio",
                    "params": ["mesh_density", "deform_scale", "rotation"]
                },
                {
                    "id": "circular_spectrum",
                    "name": "Circular Spectrum",
                    "description": "Radial frequency bars with glow effects",
                    "params": ["bar_count", "inner_radius", "glow_radius"]
                }
            ],
            "color_schemes": list(self.color_schemes.keys()),
            "resolutions": ["1920x1080", "1280x720", "3840x2160", "1080x1920"]
        }

    def generate(
        self,
        audio_path: str,
        effect_type: str = "waveform",
        resolution: str = "1920x1080",
        color_scheme: str = "neon",
        duration: int = 30,
        output_path: Optional[str] = None
    ) -> str:
        """
        Generate visual effect video synced to audio.

        Returns:
            Path to generated MP4 file
        """
        # Load audio
        audio, sr = torchaudio.load(audio_path)
        if sr != self.sample_rate:
            audio = torchaudio.functional.resample(audio, sr, self.sample_rate)

        # Trim or pad to target duration
        target_samples = duration * self.sample_rate
        if audio.shape[1] > target_samples:
            audio = audio[:, :target_samples]
        elif audio.shape[1] < target_samples:
            padding = target_samples - audio.shape[1]
            audio = torch.nn.functional.pad(audio, (0, padding))

        # Parse resolution
        width, height = map(int, resolution.split("x"))

        # Generate frames
        colors = self.color_schemes.get(color_scheme, self.color_schemes["neon"])

        if effect_type == "waveform":
            frames = self._generate_waveform_frames(audio, width, height, colors, duration)
        elif effect_type == "spectrogram":
            frames = self._generate_spectrogram_frames(audio, width, height, colors, duration)
        elif effect_type == "chromagram":
            frames = self._generate_chromagram_frames(audio, width, height, colors, duration)
        elif effect_type == "particles":
            frames = self._generate_particle_frames(audio, width, height, colors, duration)
        elif effect_type == "circular_spectrum":
            frames = self._generate_circular_spectrum_frames(audio, width, height, colors, duration)
        else:
            frames = self._generate_waveform_frames(audio, width, height, colors, duration)

        # Save frames and combine with audio
        return self._compile_video(frames, audio, output_path, duration)

    def _generate_waveform_frames(
        self,
        audio: torch.Tensor,
        width: int,
        height: int,
        colors: Dict,
        duration: int
    ) -> List[np.ndarray]:
        """Generate reactive waveform bar frames."""
        frames = []
        num_bars = 128
        samples_per_frame = self.sample_rate // self.fps
        total_frames = duration * self.fps

        # Convert to mono and compute RMS
        mono = audio.mean(dim=0).numpy()

        # Create custom colormap
        cmap = LinearSegmentedColormap.from_list("custom", colors["gradient"])

        for frame_idx in range(total_frames):
            start_sample = frame_idx * samples_per_frame
            end_sample = start_sample + samples_per_frame

            if end_sample > len(mono):
                break

            frame_audio = mono[start_sample:end_sample]

            # Compute FFT for frequency bars
            fft = np.fft.rfft(frame_audio)
            fft_mag = np.abs(fft)

            # Group into bars (logarithmic scale)
            bar_heights = np.zeros(num_bars)
            for i in range(num_bars):
                start_bin = int(len(fft_mag) * (i / num_bars) ** 2)
                end_bin = int(len(fft_mag) * ((i + 1) / num_bars) ** 2)
                if end_bin > start_bin:
                    bar_heights[i] = np.mean(fft_mag[start_bin:end_bin])

            # Normalize and smooth
            bar_heights = gaussian_filter1d(bar_heights, sigma=2)
            if bar_heights.max() > 0:
                bar_heights = bar_heights / bar_heights.max()

            # Create frame
            fig, ax = plt.subplots(figsize=(width/100, height/100), dpi=100)
            fig.patch.set_facecolor(colors["bg"])
            ax.set_facecolor(colors["bg"])

            # Draw bars with glow effect
            bar_width = (width / num_bars) * 0.8
            x_positions = np.linspace(0, width, num_bars)

            for i, (x, h) in enumerate(zip(x_positions, bar_heights)):
                bar_height = h * height * 0.8
                color = cmap(h)

                # Main bar
                rect = Rectangle(
                    (x - bar_width/2, height/2 - bar_height/2),
                    bar_width, bar_height,
                    facecolor=color,
                    edgecolor='none',
                    alpha=0.9
                )
                ax.add_patch(rect)

                # Glow effect (wider, lower opacity)
                glow = Rectangle(
                    (x - bar_width, height/2 - bar_height/2),
                    bar_width * 2, bar_height,
                    facecolor=color,
                    edgecolor='none',
                    alpha=0.2
                )
                ax.add_patch(glow)

            ax.set_xlim(0, width)
            ax.set_ylim(0, height)
            ax.axis('off')

            # Add center line
            ax.axhline(y=height/2, color=colors["primary"], alpha=0.3, linewidth=1)

            fig.canvas.draw()
            frame = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
            frame = frame.reshape(fig.canvas.get_width_height()[::-1] + (3,))
            frames.append(frame)
            plt.close(fig)

        return frames

    def _generate_spectrogram_frames(
        self,
        audio: torch.Tensor,
        width: int,
        height: int,
        colors: Dict,
        duration: int
    ) -> List[np.ndarray]:
        """Generate 3D spectrogram frames."""
        frames = []
        mono = audio.mean(dim=0).numpy()

        # Compute full spectrogram
        f, t, Sxx = signal.spectrogram(mono, self.sample_rate, nperseg=2048, noverlap=1024)

        # Log scale
        Sxx = 10 * np.log10(Sxx + 1e-10)

        total_frames = min(duration * self.fps, len(t))

        for frame_idx in range(total_frames):
            fig, ax = plt.subplots(figsize=(width/100, height/100), dpi=100)
            fig.patch.set_facecolor(colors["bg"])
            ax.set_facecolor(colors["bg"])

            # Show spectrogram up to current time
            current_t = frame_idx / self.fps
            t_idx = int(current_t * len(t) / duration)

            # Create 3D perspective effect
            display_spec = Sxx[:, :max(t_idx, 1)]

            # Custom colormap
            cmap = LinearSegmentedColormap.from_list("custom", colors["gradient"])

            im = ax.imshow(
                display_spec,
                aspect='auto',
                cmap=cmap,
                origin='lower',
                extent=[0, current_t, f[0], f[-1]],
                vmin=Sxx.min(),
                vmax=Sxx.max()
            )

            ax.set_ylim(0, 8000)  # Focus on audible range
            ax.set_xlabel('Time (s)', color='white')
            ax.set_ylabel('Frequency (Hz)', color='white')
            ax.tick_params(colors='white')
            ax.spines['bottom'].set_color('white')
            ax.spines['left'].set_color('white')

            fig.canvas.draw()
            frame = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
            frame = frame.reshape(fig.canvas.get_width_height()[::-1] + (3,))
            frames.append(frame)
            plt.close(fig)

        return frames

    def _generate_chromagram_frames(
        self,
        audio: torch.Tensor,
        width: int,
        height: int,
        colors: Dict,
        duration: int
    ) -> List[np.ndarray]:
        """Generate chromagram (pitch class) circular visualization."""
        frames = []
        mono = audio.mean(dim=0).numpy()

        # Compute chromagram
        hop_length = 512
        chroma = librosa.feature.chroma_stft(y=mono, sr=self.sample_rate, hop_length=hop_length)

        total_frames = duration * self.fps
        frames_per_chroma = chroma.shape[1] / (duration * self.fps)

        pitch_classes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

        for frame_idx in range(total_frames):
            fig, ax = plt.subplots(figsize=(width/100, height/100), dpi=100)
            fig.patch.set_facecolor(colors["bg"])
            ax.set_facecolor(colors["bg"])

            # Get current chroma values
            chroma_idx = int(frame_idx * frames_per_chroma)
            if chroma_idx >= chroma.shape[1]:
                chroma_idx = chroma.shape[1] - 1

            values = chroma[:, chroma_idx]

            # Draw circular chromagram
            center_x, center_y = width / 2, height / 2
            max_radius = min(width, height) * 0.4

            for i, (pitch, val) in enumerate(zip(pitch_classes, values)):
                angle = 2 * np.pi * i / 12 - np.pi / 2

                # Outer ring bar
                bar_length = val * max_radius * 0.8
                end_x = center_x + np.cos(angle) * (max_radius * 0.5 + bar_length)
                end_y = center_y + np.sin(angle) * (max_radius * 0.5 + bar_length)

                color_intensity = val
                color = plt.cm.get_cmap('hsv')(i / 12)

                ax.plot([center_x + np.cos(angle) * max_radius * 0.5, end_x],
                       [center_y + np.sin(angle) * max_radius * 0.5, end_y],
                       color=color, linewidth=8, alpha=0.9)

                # Label
                label_x = center_x + np.cos(angle) * (max_radius * 0.9)
                label_y = center_y + np.sin(angle) * (max_radius * 0.9)
                ax.text(label_x, label_y, pitch, color='white', fontsize=14, 
                       ha='center', va='center', fontweight='bold')

            # Center circle
            circle = Circle((center_x, center_y), max_radius * 0.45, 
                          facecolor=colors["bg"], edgecolor=colors["primary"], linewidth=3)
            ax.add_patch(circle)

            ax.set_xlim(0, width)
            ax.set_ylim(0, height)
            ax.axis('off')
            ax.set_aspect('equal')

            fig.canvas.draw()
            frame = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
            frame = frame.reshape(fig.canvas.get_width_height()[::-1] + (3,))
            frames.append(frame)
            plt.close(fig)

        return frames

    def _generate_particle_frames(
        self,
        audio: torch.Tensor,
        width: int,
        height: int,
        colors: Dict,
        duration: int
    ) -> List[np.ndarray]:
        """Generate particle system frames."""
        frames = []
        mono = audio.mean(dim=0).numpy()
        samples_per_frame = self.sample_rate // self.fps
        total_frames = duration * self.fps

        # Initialize particles
        num_particles = 200
        np.random.seed(42)
        particles = {
            'x': np.random.uniform(0, width, num_particles),
            'y': np.random.uniform(0, height, num_particles),
            'vx': np.random.uniform(-2, 2, num_particles),
            'vy': np.random.uniform(-2, 2, num_particles),
            'size': np.random.uniform(2, 8, num_particles),
            'life': np.random.uniform(0.5, 1.0, num_particles)
        }

        for frame_idx in range(total_frames):
            start_sample = frame_idx * samples_per_frame
            end_sample = min(start_sample + samples_per_frame, len(mono))

            # Get audio energy
            energy = np.abs(mono[start_sample:end_sample]).mean()

            fig, ax = plt.subplots(figsize=(width/100, height/100), dpi=100)
            fig.patch.set_facecolor(colors["bg"])
            ax.set_facecolor(colors["bg"])

            # Update particles based on audio energy
            explosion_force = energy * 50

            for i in range(num_particles):
                # Apply audio-reactive force from center
                center_x, center_y = width / 2, height / 2
                dx = particles['x'][i] - center_x
                dy = particles['y'][i] - center_y
                dist = np.sqrt(dx**2 + dy**2) + 0.1

                particles['vx'][i] += (dx / dist) * explosion_force * 0.1
                particles['vy'][i] += (dy / dist) * explosion_force * 0.1

                # Update position
                particles['x'][i] += particles['vx'][i]
                particles['y'][i] += particles['vy'][i]

                # Damping
                particles['vx'][i] *= 0.95
                particles['vy'][i] *= 0.95

                # Wrap around
                particles['x'][i] = particles['x'][i] % width
                particles['y'][i] = particles['y'][i] % height

                # Draw particle with glow
                alpha = particles['life'][i]
                color = colors["primary"] if i % 2 == 0 else colors["secondary"]

                circle = Circle(
                    (particles['x'][i], particles['y'][i]),
                    particles['size'][i] * (1 + energy * 3),
                    facecolor=color,
                    edgecolor='none',
                    alpha=alpha * 0.8
                )
                ax.add_patch(circle)

                # Glow
                glow = Circle(
                    (particles['x'][i], particles['y'][i]),
                    particles['size'][i] * (2 + energy * 5),
                    facecolor=color,
                    edgecolor='none',
                    alpha=alpha * 0.2
                )
                ax.add_patch(glow)

            ax.set_xlim(0, width)
            ax.set_ylim(0, height)
            ax.axis('off')

            fig.canvas.draw()
            frame = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
            frame = frame.reshape(fig.canvas.get_width_height()[::-1] + (3,))
            frames.append(frame)
            plt.close(fig)

        return frames

    def _generate_circular_spectrum_frames(
        self,
        audio: torch.Tensor,
        width: int,
        height: int,
        colors: Dict,
        duration: int
    ) -> List[np.ndarray]:
        """Generate circular spectrum analyzer frames."""
        frames = []
        mono = audio.mean(dim=0).numpy()
        samples_per_frame = self.sample_rate // self.fps
        total_frames = duration * self.fps
        num_bars = 64

        for frame_idx in range(total_frames):
            start_sample = frame_idx * samples_per_frame
            end_sample = start_sample + samples_per_frame

            if end_sample > len(mono):
                break

            frame_audio = mono[start_sample:end_sample]
            fft = np.fft.rfft(frame_audio)
            fft_mag = np.abs(fft)

            # Group into bars
            bar_values = np.zeros(num_bars)
            for i in range(num_bars):
                start_bin = int(len(fft_mag) * (i / num_bars) ** 2)
                end_bin = int(len(fft_mag) * ((i + 1) / num_bars) ** 2)
                if end_bin > start_bin:
                    bar_values[i] = np.mean(fft_mag[start_bin:end_bin])

            bar_values = gaussian_filter1d(bar_values, sigma=1.5)
            if bar_values.max() > 0:
                bar_values = bar_values / bar_values.max()

            fig, ax = plt.subplots(figsize=(width/100, height/100), dpi=100)
            fig.patch.set_facecolor(colors["bg"])
            ax.set_facecolor(colors["bg"])

            center_x, center_y = width / 2, height / 2
            inner_radius = min(width, height) * 0.15
            max_radius = min(width, height) * 0.45

            cmap = LinearSegmentedColormap.from_list("custom", colors["gradient"])

            for i, val in enumerate(bar_values):
                angle = 2 * np.pi * i / num_bars - np.pi / 2
                bar_length = val * (max_radius - inner_radius)

                # Calculate bar coordinates
                x1 = center_x + np.cos(angle) * inner_radius
                y1 = center_y + np.sin(angle) * inner_radius
                x2 = center_x + np.cos(angle) * (inner_radius + bar_length)
                y2 = center_y + np.sin(angle) * (inner_radius + bar_length)

                color = cmap(val)

                # Draw bar with width
                bar_width = 2 * np.pi * inner_radius / num_bars * 0.7
                ax.plot([x1, x2], [y1, y2], color=color, linewidth=bar_width/5, 
                       solid_capstyle='round')

                # Glow
                ax.plot([x1, x2], [y1, y2], color=color, linewidth=bar_width/2, 
                       alpha=0.3, solid_capstyle='round')

            # Inner circle
            circle = Circle((center_x, center_y), inner_radius * 0.9,
                          facecolor=colors["bg"], edgecolor=colors["primary"], linewidth=2)
            ax.add_patch(circle)

            ax.set_xlim(0, width)
            ax.set_ylim(0, height)
            ax.axis('off')
            ax.set_aspect('equal')

            fig.canvas.draw()
            frame = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
            frame = frame.reshape(fig.canvas.get_width_height()[::-1] + (3,))
            frames.append(frame)
            plt.close(fig)

        return frames

    def _compile_video(
        self,
        frames: List[np.ndarray],
        audio: torch.Tensor,
        output_path: Optional[str],
        duration: int
    ) -> str:
        """Compile frames and audio into MP4 video."""
        if output_path is None:
            output_path = f"/tmp/viola_effect_{uuid.uuid4().hex}.mp4"

        # Save frames as temporary images
        temp_dir = tempfile.mkdtemp()
        for i, frame in enumerate(frames):
            frame_path = f"{temp_dir}/frame_{i:05d}.png"
            cv2.imwrite(frame_path, cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))

        # Save audio
        audio_path = f"{temp_dir}/audio.wav"
        torchaudio.save(audio_path, audio, self.sample_rate)

        # Compile with ffmpeg
        ffmpeg_cmd = [
            self.ffmpeg_path,
            '-y',
            '-framerate', str(self.fps),
            '-i', f'{temp_dir}/frame_%05d.png',
            '-i', audio_path,
            '-c:v', 'libx264',
            '-preset', 'medium',
            '-crf', '23',
            '-pix_fmt', 'yuv420p',
            '-c:a', 'aac',
            '-b:a', '320k',
            '-shortest',
            output_path
        ]

        subprocess.run(ffmpeg_cmd, capture_output=True, text=True)

        # Cleanup
        import shutil
        shutil.rmtree(temp_dir)

        return output_path

# Import librosa for chromagram
import librosa
import uuid
