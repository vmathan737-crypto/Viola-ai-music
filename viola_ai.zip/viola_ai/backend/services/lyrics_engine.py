"""
AI Lyrics Generation & MIDI Export Engine
Generates lyrics based on prompt and exports to MIDI format.
"""

import torch
import numpy as np
from typing import List, Dict, Optional, Tuple
from pathlib import Path
import json
import re

class LyricsEngine:
    """
    Generate lyrics and vocal melodies for AI music.
    Uses open-source language models and music theory.
    """

    def __init__(self, device: str = "cuda"):
        self.device = device

        # Load open-source lyric generation model
        # In production: Use GPT-2 fine-tuned on lyrics or similar
        print("Lyrics Engine initialized")

    def generate_lyrics(
        self,
        prompt: str,
        style: str = "pop",
        verse_count: int = 2,
        chorus_count: int = 1,
        bridge: bool = False,
        language: str = "en"
    ) -> Dict:
        """
        Generate song lyrics based on prompt.

        Returns:
            {
                "title": str,
                "structure": ["verse", "chorus", "verse", "chorus", "bridge", "chorus"],
                "sections": {
                    "verse_1": {"lyrics": "...", "chords": ["C", "G", "Am", "F"]},
                    "chorus_1": {"lyrics": "...", "chords": ["F", "G", "C", "Am"]}
                },
                "bpm": int,
                "key": str
            }
        """
        # Generate structured lyrics based on prompt
        # In production: Use transformer model for generation

        title = self._generate_title(prompt)

        structure = []
        sections = {}

        # Build structure
        for i in range(verse_count):
            structure.append(f"verse_{i+1}")
            sections[f"verse_{i+1}"] = {
                "lyrics": self._generate_verse(prompt, i+1),
                "chords": self._generate_chord_progression(style, "verse")
            }

            if i < chorus_count:
                structure.append(f"chorus_{i+1}")
                sections[f"chorus_{i+1}"] = {
                    "lyrics": self._generate_chorus(prompt, i+1),
                    "chords": self._generate_chord_progression(style, "chorus")
                }

        if bridge:
            structure.append("bridge")
            sections["bridge"] = {
                "lyrics": self._generate_bridge(prompt),
                "chords": self._generate_chord_progression(style, "bridge")
            }
            structure.append(f"chorus_{chorus_count}")

        return {
            "title": title,
            "structure": structure,
            "sections": sections,
            "bpm": np.random.randint(80, 140),
            "key": np.random.choice(["C major", "G major", "A minor", "E minor", "F major"])
        }

    def _generate_title(self, prompt: str) -> str:
        """Generate song title from prompt."""
        # Extract key themes
        words = prompt.lower().split()
        themes = [w for w in words if len(w) > 3]

        if themes:
            return f"{themes[0].capitalize()} {' '.join(themes[1:2]).capitalize()}"
        return "Untitled"

    def _generate_verse(self, prompt: str, verse_num: int) -> str:
        """Generate verse lyrics."""
        # Placeholder: Generate based on prompt themes
        lines = [
            f"Walking through the shadows of {prompt[:20]}...",
            "Memories fade like morning light",
            "But the echoes remain in the night",
            "",
            f"Searching for meaning in {prompt[20:40] if len(prompt) > 20 else 'the silence'}...",
            "Every step leads to a new door",
            "What are we really looking for?"
        ]
        return "\n".join(lines)

    def _generate_chorus(self, prompt: str, chorus_num: int) -> str:
        """Generate chorus lyrics."""
        lines = [
            "This is the moment we rise",
            "Breaking through the endless skies",
            "No more hiding, no more fear",
            "The future is finally here",
            "",
            "We are the voices in the dark",
            "Lighting up every spark",
            "Together we will find our way",
            "A brand new dawn, a brand new day"
        ]
        return "\n".join(lines)

    def _generate_bridge(self, prompt: str) -> str:
        """Generate bridge lyrics."""
        lines = [
            "In the silence between the notes",
            "Where the heart and soul conspire",
            "We find the strength to carry on",
            "And set the world on fire"
        ]
        return "\n".join(lines)

    def _generate_chord_progression(self, style: str, section: str) -> List[str]:
        """Generate chord progression based on style."""
        progressions = {
            "pop": {
                "verse": ["C", "G", "Am", "F"],
                "chorus": ["F", "G", "Am", "C"],
                "bridge": ["Am", "F", "C", "G"]
            },
            "rock": {
                "verse": ["E", "A", "B", "C#m"],
                "chorus": ["A", "E", "B", "C#m"],
                "bridge": ["C#m", "A", "E", "B"]
            },
            "jazz": {
                "verse": ["Dm7", "G7", "Cmaj7", "Am7"],
                "chorus": ["Cmaj7", "Am7", "Dm7", "G7"],
                "bridge": ["Am7", "Dm7", "G7", "Cmaj7"]
            },
            "electronic": {
                "verse": ["Cm", "Eb", "Bb", "Ab"],
                "chorus": ["Ab", "Bb", "Cm", "Eb"],
                "bridge": ["Eb", "Ab", "Bb", "Cm"]
            }
        }

        style_progs = progressions.get(style, progressions["pop"])
        return style_progs.get(section, style_progs["verse"])

    def export_to_midi(
        self,
        lyrics_data: Dict,
        output_path: str,
        tempo: Optional[int] = None
    ) -> str:
        """
        Export lyrics and chords to MIDI file.

        Returns:
            Path to MIDI file
        """
        try:
            import mido
            from mido import Message, MidiFile, MidiTrack, MetaMessage
        except ImportError:
            print("mido not installed. Install with: pip install mido")
            return None

        mid = MidiFile()
        track = MidiTrack()
        mid.tracks.append(track)

        # Set tempo
        bpm = tempo or lyrics_data.get("bpm", 120)
        track.append(MetaMessage('set_tempo', tempo=mido.bpm2tempo(bpm)))

        # Add track name
        track.append(MetaMessage('track_name', name=lyrics_data.get("title", "Viola AI")))

        # Chord to MIDI note mapping
        chord_notes = {
            'C': [60, 64, 67], 'Cm': [60, 63, 67],
            'G': [67, 71, 74], 'Gm': [67, 70, 74],
            'Am': [69, 72, 76], 'A': [69, 73, 76],
            'F': [65, 69, 72], 'Fm': [65, 68, 72],
            'D': [62, 66, 69], 'Dm': [62, 65, 69],
            'E': [64, 68, 71], 'Em': [64, 67, 71],
            'B': [71, 75, 78], 'Bm': [71, 74, 78],
            'C#m': [61, 64, 68], 'Eb': [63, 67, 70],
            'Bb': [70, 74, 77], 'Ab': [68, 72, 75],
            'Cmaj7': [60, 64, 67, 71], 'Dm7': [62, 65, 69, 72],
            'G7': [67, 71, 74, 77], 'Am7': [69, 72, 76, 79]
        }

        ticks_per_beat = mid.ticks_per_beat
        chord_duration = ticks_per_beat * 2  # 2 beats per chord

        # Add chords from structure
        for section_name in lyrics_data.get("structure", []):
            section = lyrics_data["sections"].get(section_name, {})
            chords = section.get("chords", ["C", "G", "Am", "F"])

            for chord in chords:
                notes = chord_notes.get(chord, [60, 64, 67])

                # Note on
                for note in notes:
                    track.append(Message('note_on', note=note, velocity=80, time=0))

                # Note off
                for i, note in enumerate(notes):
                    track.append(Message('note_off', note=note, velocity=0, 
                                       time=chord_duration if i == 0 else 0))

        mid.save(output_path)
        return output_path

    def export_to_lrc(self, lyrics_data: Dict, output_path: str) -> str:
        """
        Export lyrics to LRC format (for karaoke).

        Returns:
            Path to LRC file
        """
        lrc_content = f"[ti:{lyrics_data.get('title', 'Untitled')}]\n"
        lrc_content += f"[ar:Viola AI]\n"
        lrc_content += f"[al:Generated]\n"
        lrc_content += f"[by:Viola AI Lyrics Engine]\n\n"

        time_ms = 0
        bpm = lyrics_data.get("bpm", 120)
        ms_per_beat = 60000 / bpm

        for section_name in lyrics_data.get("structure", []):
            section = lyrics_data["sections"].get(section_name, {})
            lyrics = section.get("lyrics", "")

            for line in lyrics.split("\n"):
                if line.strip():
                    minutes = int(time_ms / 60000)
                    seconds = int((time_ms % 60000) / 1000)
                    centiseconds = int((time_ms % 1000) / 10)

                    lrc_content += f"[{minutes:02d}:{seconds:02d}.{centiseconds:02d}]{line}\n"
                    time_ms += ms_per_beat * 4  # 4 beats per line

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(lrc_content)

        return output_path


class MIDIExporter:
    """
    Export generated music to MIDI format for DAW integration.
    """

    def __init__(self):
        self.sample_rate = 32000

    def audio_to_midi(
        self,
        audio_path: str,
        output_path: str,
        method: str = "piano_transcription"
    ) -> str:
        """
        Convert audio to MIDI using pitch detection.

        Args:
            audio_path: Path to audio file
            output_path: Output MIDI path
            method: "piano_transcription" or "basic_pitch"

        Returns:
            Path to MIDI file
        """
        try:
            import librosa
            import mido
        except ImportError:
            print("Install librosa and mido for MIDI export")
            return None

        # Load audio
        y, sr = librosa.load(audio_path, sr=self.sample_rate)

        # Detect pitch
        pitches, magnitudes = librosa.piptrack(y=y, sr=sr)

        # Create MIDI file
        mid = mido.MidiFile()
        track = mido.MidiTrack()
        mid.tracks.append(track)

        track.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(120)))

        # Extract notes from pitch detection
        # This is a simplified version - production would use more sophisticated methods

        hop_length = 512
        for t in range(0, pitches.shape[1], 10):  # Sample every 10 frames
            frame_pitches = pitches[:, t]
            frame_mags = magnitudes[:, t]

            # Find strongest pitch
            if frame_mags.max() > 0:
                max_idx = frame_mags.argmax()
                midi_note = int(librosa.hz_to_midi(frame_pitches[max_idx]))

                if 0 < midi_note < 127:
                    track.append(mido.Message('note_on', note=midi_note, velocity=100, time=0))
                    track.append(mido.Message('note_off', note=midi_note, velocity=0, 
                                            time=hop_length))

        mid.save(output_path)
        return output_path

    def generate_drum_midi(
        self,
        pattern: str = "basic_rock",
        bars: int = 4,
        output_path: str = "drums.mid"
    ) -> str:
        """
        Generate drum MIDI patterns.

        Args:
            pattern: Drum pattern style
            bars: Number of bars
            output_path: Output path
        """
        try:
            import mido
        except ImportError:
            print("Install mido for MIDI export")
            return None

        # GM Drum map
        drums = {
            "kick": 36,
            "snare": 38,
            "hihat_closed": 42,
            "hihat_open": 46,
            "crash": 49,
            "tom1": 50,
            "tom2": 47,
            "ride": 51
        }

        patterns = {
            "basic_rock": [
                ["kick", "hihat_closed"],
                ["hihat_closed"],
                ["snare", "hihat_closed"],
                ["hihat_closed"]
            ],
            "four_on_floor": [
                ["kick", "hihat_closed"],
                ["hihat_closed"],
                ["kick", "hihat_closed"],
                ["hihat_closed"]
            ],
            "breakbeat": [
                ["kick", "hihat_closed"],
                ["hihat_closed"],
                ["snare", "hihat_closed"],
                ["hihat_closed", "kick"]
            ]
        }

        drum_pattern = patterns.get(pattern, patterns["basic_rock"])

        mid = mido.MidiFile()
        track = mido.MidiTrack()
        mid.tracks.append(track)

        # Set to drum channel (10)
        track.append(mido.Message('program_change', channel=9, program=0, time=0))

        ticks_per_beat = mid.ticks_per_beat
        step_duration = ticks_per_beat // 4  # 16th notes

        for bar in range(bars):
            for step in drum_pattern:
                for drum_name in step:
                    note = drums.get(drum_name, 36)
                    track.append(mido.Message('note_on', channel=9, note=note, 
                                            velocity=100, time=0))

                # Note offs
                for i, drum_name in enumerate(step):
                    note = drums.get(drum_name, 36)
                    track.append(mido.Message('note_off', channel=9, note=note, 
                                            velocity=0, time=step_duration if i == 0 else 0))

        mid.save(output_path)
        return output_path
