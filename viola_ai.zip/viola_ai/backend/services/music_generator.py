"""
MusicGen-based music generation with 5-minute sliding window continuation.
Handles long-form generation by overlapping windows and maintaining coherence.
"""

import torch
import torchaudio
import numpy as np
from typing import Optional, List, Tuple
from pathlib import Path
import tempfile
import soundfile as sf

from audiocraft.models import MusicGen
from audiocraft.data.audio import audio_write
from audiocraft.modules.conditioners import ConditioningAttributes

class MusicGenerator:
    """
    Open-source music generation using Meta's MusicGen.
    Supports up to 5-minute generation via sliding window continuation.
    """

    def __init__(self, device: str = "cuda", model_size: str = "large"):
        self.device = device
        self.model_size = model_size
        self.sample_rate = 32000

        # Load model
        print(f"Loading MusicGen {model_size} model...")
        self.model = MusicGen.get_pretrained(f"facebook/musicgen-{model_size}", device=device)
        self.model.set_generation_params(
            duration=30,  # Base window size
            top_k=250,
            top_p=0.9,
            temperature=1.0,
            cfg_coef=7.0
        )
        print(f"✅ MusicGen {model_size} loaded on {device}")

    def generate(
        self,
        prompt: str,
        duration: int = 30,
        style_tags: Optional[List[str]] = None,
        melody: Optional[torch.Tensor] = None,
        bpm: Optional[int] = None,
        key: Optional[str] = None,
        cfg_scale: float = 7.0,
        temperature: float = 1.0,
        top_k: int = 250,
        top_p: float = 0.9,
        progress_callback=None
    ) -> torch.Tensor:
        """
        Generate music up to 5 minutes (300 seconds).
        Uses sliding window for durations > 30 seconds.
        """
        # Build enhanced prompt with metadata
        enhanced_prompt = self._build_prompt(prompt, style_tags, bpm, key)

        if duration <= 30:
            # Single generation for short clips
            self.model.set_generation_params(
                duration=duration,
                cfg_coef=cfg_scale,
                temperature=temperature,
                top_k=top_k,
                top_p=top_p
            )

            if melody is not None:
                wav = self.model.generate_with_chroma(
                    descriptions=[enhanced_prompt],
                    melody_wavs=melody[None],
                    melody_sample_rate=self.sample_rate
                )
            else:
                wav = self.model.generate([enhanced_prompt])

            return wav[0]  # Return first (and only) sample

        else:
            # Long generation via sliding window
            return self._generate_long(
                prompt=enhanced_prompt,
                target_duration=duration,
                melody=melody,
                cfg_scale=cfg_scale,
                temperature=temperature,
                top_k=top_k,
                top_p=top_p,
                progress_callback=progress_callback
            )

    def _generate_long(
        self,
        prompt: str,
        target_duration: int,
        melody: Optional[torch.Tensor] = None,
        cfg_scale: float = 7.0,
        temperature: float = 1.0,
        top_k: int = 250,
        top_p: float = 0.9,
        progress_callback=None
    ) -> torch.Tensor:
        """
        Generate long music using sliding window with overlap.
        Window: 30s, Step: 10s, Overlap: 20s
        """
        window_size = 30  # seconds
        step_size = 10    # seconds
        overlap = window_size - step_size  # 20 seconds overlap

        num_windows = (target_duration - window_size) // step_size + 1
        if (target_duration - window_size) % step_size > 0:
            num_windows += 1

        print(f"Generating {target_duration}s music in {num_windows} windows...")

        # Initialize with first window
        self.model.set_generation_params(
            duration=window_size,
            cfg_coef=cfg_scale,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p
        )

        if melody is not None:
            full_audio = self.model.generate_with_chroma(
                descriptions=[prompt],
                melody_wavs=melody[None],
                melody_sample_rate=self.sample_rate
            )[0]
        else:
            full_audio = self.model.generate([prompt])[0]

        if progress_callback:
            progress_callback(1, num_windows, "First window generated")

        # Continue with sliding windows
        for i in range(1, num_windows):
            # Use last 20s as prompt for continuation
            prompt_audio = full_audio[:, -overlap * self.sample_rate:]

            # Generate next window
            self.model.set_generation_params(duration=window_size)

            # Use continuation (audio prompt)
            continuation = self.model.generate_continuation(
                prompt_audio[None],
                prompt_sample_rate=self.sample_rate,
                descriptions=[prompt]
            )[0]

            # Crossfade overlap region
            crossfade_samples = overlap * self.sample_rate
            fade_out = torch.linspace(1, 0, crossfade_samples).to(self.device)
            fade_in = torch.linspace(0, 1, crossfade_samples).to(self.device)

            # Apply crossfade
            full_audio[:, -crossfade_samples:] *= fade_out
            continuation[:, :crossfade_samples] *= fade_in
            full_audio[:, -crossfade_samples:] += continuation[:, :crossfade_samples]

            # Append new content
            full_audio = torch.cat([
                full_audio,
                continuation[:, crossfade_samples:]
            ], dim=1)

            if progress_callback:
                progress_callback(i + 1, num_windows, f"Window {i+1}/{num_windows} generated")

            print(f"  Window {i+1}/{num_windows} complete - Total: {full_audio.shape[1] / self.sample_rate:.1f}s")

        # Trim to exact target duration
        target_samples = target_duration * self.sample_rate
        if full_audio.shape[1] > target_samples:
            full_audio = full_audio[:, :target_samples]

        print(f"✅ Generated {full_audio.shape[1] / self.sample_rate:.1f}s audio")
        return full_audio

    def continue_audio(
        self,
        audio_path: str,
        extend_duration: int = 30,
        prompt: Optional[str] = None
    ) -> torch.Tensor:
        """Continue existing audio from the end."""
        # Load existing audio
        audio, sr = torchaudio.load(audio_path)
        if sr != self.sample_rate:
            audio = torchaudio.functional.resample(audio, sr, self.sample_rate)

        # Use last 10s as prompt
        prompt_length = min(10 * self.sample_rate, audio.shape[1])
        prompt_audio = audio[:, -prompt_length:]

        # Generate continuation
        self.model.set_generation_params(duration=extend_duration)

        description = prompt or "Continue the music seamlessly"
        continuation = self.model.generate_continuation(
            prompt_audio[None],
            prompt_sample_rate=self.sample_rate,
            descriptions=[description]
        )[0]

        # Crossfade and concatenate
        crossfade_samples = 2 * self.sample_rate  # 2s crossfade
        fade_out = torch.linspace(1, 0, crossfade_samples).to(self.device)
        fade_in = torch.linspace(0, 1, crossfade_samples).to(self.device)

        audio[:, -crossfade_samples:] *= fade_out
        continuation[:, :crossfade_samples] *= fade_in
        audio[:, -crossfade_samples:] += continuation[:, :crossfade_samples]

        return torch.cat([audio, continuation[:, crossfade_samples:]], dim=1)

    def remix(
        self,
        audio_path: str,
        style_prompt: str,
        intensity: float = 0.5
    ) -> torch.Tensor:
        """Remix audio with new style while preserving structure."""
        # Load audio
        audio, sr = torchaudio.load(audio_path)
        if sr != self.sample_rate:
            audio = torchaudio.functional.resample(audio, sr, self.sample_rate)

        # Extract melody/chroma as conditioning
        duration = audio.shape[1] / self.sample_rate

        # Generate with melody conditioning and new style
        self.model.set_generation_params(duration=min(duration, 30))

        # Use chromagram for melody guidance
        wav = self.model.generate_with_chroma(
            descriptions=[style_prompt],
            melody_wavs=audio[None],
            melody_sample_rate=self.sample_rate
        )[0]

        # Blend original and generated based on intensity
        if intensity < 1.0 and audio.shape[1] == wav.shape[1]:
            wav = intensity * wav + (1 - intensity) * audio

        return wav

    def _build_prompt(
        self,
        prompt: str,
        style_tags: Optional[List[str]] = None,
        bpm: Optional[int] = None,
        key: Optional[str] = None
    ) -> str:
        """Build enhanced prompt with metadata."""
        parts = [prompt]

        if style_tags:
            parts.append(f"Style: {', '.join(style_tags)}")

        if bpm:
            parts.append(f"{bpm} BPM")

        if key:
            parts.append(f"Key: {key}")

        return ". ".join(parts)

    def cleanup(self):
        """Free GPU memory."""
        del self.model
        torch.cuda.empty_cache()
