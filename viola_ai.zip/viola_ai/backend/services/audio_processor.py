"""
Audio processing utilities for Viola AI.
Handles loading, saving, resampling, and format conversion.
"""

import torch
import torchaudio
import numpy as np
from typing import Optional, Union, Tuple
from pathlib import Path
import tempfile
import os

class AudioProcessor:
    """Utility class for audio processing operations."""

    def __init__(self, target_sample_rate: int = 32000):
        self.target_sample_rate = target_sample_rate

    def load_audio(
        self,
        audio_data: Optional[bytes] = None,
        audio_path: Optional[str] = None,
        target_sr: Optional[int] = None
    ) -> Tuple[torch.Tensor, int]:
        """
        Load audio from bytes or path.

        Returns:
            (audio_tensor, sample_rate)
        """
        sr = target_sr or self.target_sample_rate

        if audio_data:
            # Save to temp file and load
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                tmp.write(audio_data)
                tmp_path = tmp.name

            audio, orig_sr = torchaudio.load(tmp_path)
            os.unlink(tmp_path)
        elif audio_path:
            audio, orig_sr = torchaudio.load(audio_path)
        else:
            raise ValueError("Either audio_data or audio_path must be provided")

        # Resample if needed
        if orig_sr != sr:
            audio = torchaudio.functional.resample(audio, orig_sr, sr)

        return audio, sr

    def save_audio(
        self,
        audio: torch.Tensor,
        output_path: str,
        sample_rate: Optional[int] = None,
        format: str = "wav",
        bitrate: int = 320
    ) -> str:
        """
        Save audio to file.

        Args:
            audio: Audio tensor [channels, samples]
            output_path: Output file path
            sample_rate: Sample rate (default: target_sample_rate)
            format: Output format (wav, mp3, flac)
            bitrate: MP3 bitrate in kbps
        """
        sr = sample_rate or self.target_sample_rate

        # Ensure directory exists
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        if format == "wav":
            torchaudio.save(output_path, audio, sr)
        elif format == "mp3":
            # Save as wav first, then convert
            temp_wav = output_path.replace(".mp3", "_temp.wav")
            torchaudio.save(temp_wav, audio, sr)

            import subprocess
            subprocess.run([
                "ffmpeg", "-i", temp_wav,
                "-codec:a", "libmp3lame",
                "-b:a", f"{bitrate}k",
                "-y", output_path
            ], capture_output=True)

            os.remove(temp_wav)
        elif format == "flac":
            torchaudio.save(output_path, audio, sr, format="FLAC")

        return output_path

    def normalize(
        self,
        audio: torch.Tensor,
        target_lufs: float = -14.0
    ) -> torch.Tensor:
        """
        Normalize audio to target LUFS loudness.
        """
        # Simple peak normalization (for production, use pyloudnorm)
        peak = torch.max(torch.abs(audio))
        if peak > 0:
            audio = audio / peak * 0.8
        return audio

    def trim_silence(
        self,
        audio: torch.Tensor,
        threshold_db: float = -60.0
    ) -> torch.Tensor:
        """
        Trim silence from start and end.
        """
        threshold = 10 ** (threshold_db / 20)

        # Find non-silent regions
        mono = audio.mean(dim=0)
        mask = torch.abs(mono) > threshold

        if not mask.any():
            return audio

        # Find first and last non-silent sample
        indices = torch.where(mask)[0]
        start = indices[0].item()
        end = indices[-1].item()

        return audio[:, start:end]

    def apply_fade(
        self,
        audio: torch.Tensor,
        fade_in: float = 0.01,
        fade_out: float = 0.01
    ) -> torch.Tensor:
        """
        Apply fade in/out to audio.

        Args:
            fade_in: Fade in duration in seconds
            fade_out: Fade out duration in seconds
        """
        sr = self.target_sample_rate
        samples = audio.shape[1]

        # Fade in
        fade_in_samples = int(fade_in * sr)
        if fade_in_samples > 0:
            fade_in_curve = torch.linspace(0, 1, fade_in_samples)
            audio[:, :fade_in_samples] *= fade_in_curve

        # Fade out
        fade_out_samples = int(fade_out * sr)
        if fade_out_samples > 0:
            fade_out_curve = torch.linspace(1, 0, fade_out_samples)
            audio[:, -fade_out_samples:] *= fade_out_curve

        return audio

    def mix_audio(
        self,
        tracks: list,
        volumes: Optional[list] = None
    ) -> torch.Tensor:
        """
        Mix multiple audio tracks together.

        Args:
            tracks: List of audio tensors
            volumes: List of volume multipliers (0.0-1.0)
        """
        if not tracks:
            raise ValueError("No tracks provided")

        # Find max length
        max_length = max(t.shape[1] for t in tracks)

        # Pad tracks to same length
        padded_tracks = []
        for track in tracks:
            if track.shape[1] < max_length:
                padding = max_length - track.shape[1]
                track = torch.nn.functional.pad(track, (0, padding))
            padded_tracks.append(track)

        # Apply volumes and mix
        volumes = volumes or [1.0] * len(tracks)
        mixed = sum(t * v for t, v in zip(padded_tracks, volumes))

        # Prevent clipping
        peak = torch.max(torch.abs(mixed))
        if peak > 1.0:
            mixed = mixed / peak

        return mixed

    def get_audio_info(self, audio_path: str) -> dict:
        """Get audio file information."""
        info = torchaudio.info(audio_path)
        return {
            "sample_rate": info.sample_rate,
            "channels": info.num_channels,
            "duration": info.num_frames / info.sample_rate,
            "frames": info.num_frames,
            "bits_per_sample": info.bits_per_sample
        }
