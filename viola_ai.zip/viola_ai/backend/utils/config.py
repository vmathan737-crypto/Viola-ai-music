"""
Viola AI Configuration
"""

import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    """Application settings."""

    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEBUG: bool = False

    # Paths
    OUTPUT_DIR: str = "./outputs"
    UPLOAD_DIR: str = "./uploads"
    MODEL_DIR: str = "./models"

    # Redis
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0

    # Celery
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/0"

    # GPU
    CUDA_VISIBLE_DEVICES: str = "0"

    # Audio
    DEFAULT_SAMPLE_RATE: int = 32000
    MAX_DURATION: int = 300  # 5 minutes

    # Security
    MAX_UPLOAD_SIZE: int = 100 * 1024 * 1024  # 100MB
    ALLOWED_EXTENSIONS: list = [".wav", ".mp3", ".flac", ".ogg", ".m4a"]

    # API Keys (for optional cloud services)
    OPENAI_API_KEY: str = ""
    HUGGINGFACE_TOKEN: str = ""

    class Config:
        env_file = ".env"

settings = Settings()
