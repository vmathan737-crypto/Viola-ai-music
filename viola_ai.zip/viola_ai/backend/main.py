#!/usr/bin/env python3
"""
Viola AI - Open Source Music Generation & Stem Separation Platform
License: MIT
Features:
- 5-minute AI music generation via sliding window continuation
- Professional visual effects (waveform, spectrogram, chromagram)
- AI vocal extraction & instrument isolation via Demucs
- Voice synthesis & cloning (RVC/StyleTTS2)
- Real-time WebSocket progress streaming
"""

import os
import sys
import asyncio
import json
import uuid
import time
from datetime import datetime
from typing import Optional, List, Dict, Any
from pathlib import Path
from contextlib import asynccontextmanager

import torch
import torchaudio
import numpy as np
from fastapi import FastAPI, File, UploadFile, Form, WebSocket, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field
import uvicorn
from celery import Celery
import redis

# Local imports
from services.music_generator import MusicGenerator
from services.stem_separator import StemSeparator
from services.voice_engine import VoiceEngine
from services.visual_effects import VisualEffects
from services.audio_processor import AudioProcessor
from utils.config import Settings
from utils.logger import setup_logger

# Setup
settings = Settings()
logger = setup_logger("viola_ai")

# Redis & Celery for async processing
redis_client = redis.Redis(host=settings.REDIS_HOST, port=settings.REDIS_PORT, decode_responses=True)
celery_app = Celery(
    'viola_ai',
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND
)

# Global model instances (loaded once at startup)
models = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Load models on startup, cleanup on shutdown."""
    logger.info("🎵 Viola AI starting up...")

    # Check GPU availability
    device = "cuda" if torch.cuda.is_available() else "cpu"
    logger.info(f"Using device: {device}")
    if device == "cuda":
        logger.info(f"GPU: {torch.cuda.get_device_name(0)}")
        logger.info(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")

    # Load models
    models["musicgen"] = MusicGenerator(device=device, model_size="large")
    models["stem_separator"] = StemSeparator(device=device, model_name="htdemucs_ft")
    models["voice_engine"] = VoiceEngine(device=device)
    models["visual_effects"] = VisualEffects()
    models["audio_processor"] = AudioProcessor()

    logger.info("✅ All models loaded successfully")
    yield

    # Cleanup
    logger.info("Shutting down Viola AI...")
    for model in models.values():
        if hasattr(model, 'cleanup'):
            model.cleanup()

app = FastAPI(
    title="Viola AI API",
    description="Open Source AI Music Generation & Audio Processing",
    version="1.0.0",
    lifespan=lifespan
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==================== REQUEST MODELS ====================

class GenerateRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=500, description="Music description")
    duration: int = Field(default=30, ge=5, le=300, description="Duration in seconds (max 5 min)")
    style_tags: List[str] = Field(default=[], description="Genre/mood tags")
    bpm: Optional[int] = Field(default=None, ge=40, le=250, description="Beats per minute")
    key: Optional[str] = Field(default=None, description="Musical key (e.g., C major, A minor)")
    melody_file: Optional[str] = Field(default=None, description="Optional melody audio file ID")
    continuation_id: Optional[str] = Field(default=None, description="Previous generation ID to continue")
    cfg_scale: float = Field(default=7.0, ge=1.0, le=20.0, description="Classifier-free guidance scale")
    temperature: float = Field(default=1.0, ge=0.1, le=2.0)
    top_k: int = Field(default=250, ge=1, le=1000)
    top_p: float = Field(default=0.9, ge=0.1, le=1.0)

class StemSeparateRequest(BaseModel):
    audio_id: str = Field(..., description="Audio file ID to process")
    stems: List[str] = Field(default=["vocals", "drums", "bass", "other"], 
                           description="Stems to extract")
    model: str = Field(default="htdemucs_ft", description="Demucs model variant")
    two_stems: Optional[str] = Field(default=None, description="Extract only 2 stems (e.g., 'vocals')")
    segment_length: Optional[int] = Field(default=7, description="Segment length in seconds")

class VoiceCloneRequest(BaseModel):
    voice_sample_id: str = Field(..., description="Voice sample audio ID")
    text: str = Field(..., min_length=1, max_length=1000, description="Text to synthesize")
    emotion: str = Field(default="neutral", description="Emotion style")
    speed: float = Field(default=1.0, ge=0.5, le=2.0, description="Speech speed")

class VisualEffectRequest(BaseModel):
    audio_id: str = Field(..., description="Audio file ID")
    effect_type: str = Field(..., description="Effect: waveform, spectrogram, chromagram, particles")
    resolution: str = Field(default="1920x1080", description="Output resolution")
    color_scheme: str = Field(default="neon", description="Color theme: neon, sunset, ocean, matrix")
    duration: int = Field(default=30, description="Video duration in seconds")

# ==================== ENDPOINTS ====================

@app.get("/")
async def root():
    return {
        "app": "Viola AI",
        "version": "1.0.0",
        "status": "running",
        "models_loaded": list(models.keys()),
        "gpu_available": torch.cuda.is_available(),
        "gpu_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# ---- MUSIC GENERATION ----

@app.post("/api/v1/generate")
async def generate_music(request: GenerateRequest, background_tasks: BackgroundTasks):
    """
    Generate AI music up to 5 minutes using sliding window continuation.
    """
    job_id = str(uuid.uuid4())

    # Store job in Redis
    redis_client.hset(f"job:{job_id}", mapping={
        "status": "queued",
        "type": "generate",
        "created_at": datetime.now().isoformat(),
        "progress": 0,
        "total_duration": request.duration
    })

    # Queue Celery task for long generation
    task = celery_app.send_task(
        'tasks.generate_music',
        args=[job_id, request.dict()],
        queue='generation'
    )

    return {
        "job_id": job_id,
        "task_id": task.id,
        "status": "queued",
        "estimated_time": request.duration * 2,  # Rough estimate
        "websocket_url": f"/ws/jobs/{job_id}"
    }

@app.post("/api/v1/generate/quick")
async def quick_generate(
    prompt: str = Form(...),
    duration: int = Form(default=30),
    style_tags: str = Form(default=""),
    file: Optional[UploadFile] = File(None)
):
    """Quick generation endpoint (synchronous, up to 60s)."""
    if duration > 60:
        raise HTTPException(400, "Quick generation limited to 60s. Use /generate for longer.")

    tags = style_tags.split(",") if style_tags else []

    # Process melody if provided
    melody = None
    if file:
        melody_data = await file.read()
        melody = models["audio_processor"].load_audio(melody_data)

    result = models["musicgen"].generate(
        prompt=prompt,
        duration=duration,
        style_tags=tags,
        melody=melody,
        cfg_scale=7.0
    )

    audio_id = str(uuid.uuid4())
    output_path = f"{settings.OUTPUT_DIR}/{audio_id}.wav"
    models["audio_processor"].save_audio(result, output_path)

    return {
        "audio_id": audio_id,
        "duration": duration,
        "url": f"/api/v1/audio/{audio_id}",
        "prompt": prompt
    }

# ---- STEM SEPARATION ----

@app.post("/api/v1/separate")
async def separate_stems(request: StemSeparateRequest, background_tasks: BackgroundTasks):
    """
    Separate audio into stems using Demucs (vocals, drums, bass, other).
    """
    job_id = str(uuid.uuid4())

    redis_client.hset(f"job:{job_id}", mapping={
        "status": "queued",
        "type": "separate",
        "created_at": datetime.now().isoformat()
    })

    task = celery_app.send_task(
        'tasks.separate_stems',
        args=[job_id, request.dict()],
        queue='separation'
    )

    return {
        "job_id": job_id,
        "task_id": task.id,
        "status": "queued",
        "websocket_url": f"/ws/jobs/{job_id}"
    }

@app.post("/api/v1/separate/quick")
async def quick_separate(
    file: UploadFile = File(...),
    two_stems: Optional[str] = Form(default=None),
    model: str = Form(default="htdemucs")
):
    """Quick stem separation (synchronous, smaller files)."""
    audio_data = await file.read()

    result = models["stem_separator"].separate(
        audio_data=audio_data,
        model_name=model,
        two_stems=two_stems
    )

    stem_ids = {}
    for stem_name, stem_audio in result.items():
        stem_id = str(uuid.uuid4())
        output_path = f"{settings.OUTPUT_DIR}/{stem_id}.wav"
        models["audio_processor"].save_audio(stem_audio, output_path)
        stem_ids[stem_name] = stem_id

    return {
        "stems": stem_ids,
        "urls": {k: f"/api/v1/audio/{v}" for k, v in stem_ids.items()},
        "model_used": model
    }

# ---- VOICE ENGINE ----

@app.post("/api/v1/voice/clone")
async def clone_voice(request: VoiceCloneRequest):
    """
    Clone voice from sample and synthesize text.
    """
    job_id = str(uuid.uuid4())

    task = celery_app.send_task(
        'tasks.clone_voice',
        args=[job_id, request.dict()],
        queue='voice'
    )

    return {
        "job_id": job_id,
        "task_id": task.id,
        "status": "queued"
    }

@app.post("/api/v1/voice/synthesize")
async def synthesize_voice(
    text: str = Form(...),
    voice_id: Optional[str] = Form(default=None),
    emotion: str = Form(default="neutral"),
    speed: float = Form(default=1.0)
):
    """Text-to-speech synthesis."""
    result = models["voice_engine"].synthesize(
        text=text,
        voice_id=voice_id,
        emotion=emotion,
        speed=speed
    )

    audio_id = str(uuid.uuid4())
    output_path = f"{settings.OUTPUT_DIR}/{audio_id}.wav"
    models["audio_processor"].save_audio(result, output_path)

    return {
        "audio_id": audio_id,
        "url": f"/api/v1/audio/{audio_id}",
        "text": text,
        "duration": len(result) / 22050  # Assuming 22.05kHz
    }

# ---- VISUAL EFFECTS ----

@app.post("/api/v1/effects/generate")
async def generate_visual_effect(request: VisualEffectRequest):
    """
    Generate professional visual effects synced to audio.
    Effects: waveform, spectrogram, chromagram, particle_system, reactive_mesh
    """
    job_id = str(uuid.uuid4())

    redis_client.hset(f"job:{job_id}", mapping={
        "status": "queued",
        "type": "visual_effect",
        "created_at": datetime.now().isoformat()
    })

    task = celery_app.send_task(
        'tasks.generate_visual',
        args=[job_id, request.dict()],
        queue='effects'
    )

    return {
        "job_id": job_id,
        "task_id": task.id,
        "status": "queued",
        "estimated_time": request.duration * 3
    }

@app.get("/api/v1/effects/presets")
async def get_effect_presets():
    """Get available visual effect presets."""
    return models["visual_effects"].get_presets()

# ---- AUDIO MANAGEMENT ----

@app.get("/api/v1/audio/{audio_id}")
async def get_audio(audio_id: str):
    """Download generated audio file."""
    file_path = f"{settings.OUTPUT_DIR}/{audio_id}.wav"
    if not os.path.exists(file_path):
        # Try mp3
        file_path = f"{settings.OUTPUT_DIR}/{audio_id}.mp3"
        if not os.path.exists(file_path):
            raise HTTPException(404, "Audio not found")

    return FileResponse(file_path, media_type="audio/wav")

@app.get("/api/v1/jobs/{job_id}")
async def get_job_status(job_id: str):
    """Get job status and results."""
    job_data = redis_client.hgetall(f"job:{job_id}")
    if not job_data:
        raise HTTPException(404, "Job not found")

    return {
        "job_id": job_id,
        "status": job_data.get("status", "unknown"),
        "progress": int(job_data.get("progress", 0)),
        "result": job_data.get("result"),
        "error": job_data.get("error"),
        "created_at": job_data.get("created_at"),
        "completed_at": job_data.get("completed_at")
    }

# ---- WEBSOCKETS ----

@app.websocket("/ws/jobs/{job_id}")
async def websocket_job(websocket: WebSocket, job_id: str):
    """Real-time job progress updates."""
    await websocket.accept()

    try:
        while True:
            job_data = redis_client.hgetall(f"job:{job_id}")
            if not job_data:
                await websocket.send_json({"error": "Job not found"})
                break

            await websocket.send_json({
                "job_id": job_id,
                "status": job_data.get("status"),
                "progress": int(job_data.get("progress", 0)),
                "message": job_data.get("message", "")
            })

            if job_data.get("status") in ["completed", "failed"]:
                break

            await asyncio.sleep(1)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        await websocket.close()

# ---- SUNO-STYLE FEATURES ----

@app.post("/api/v1/extend")
async def extend_audio(
    audio_id: str = Form(...),
    extend_duration: int = Form(default=30),
    prompt: Optional[str] = Form(default=None)
):
    """Extend existing audio by continuing from the end."""
    input_path = f"{settings.OUTPUT_DIR}/{audio_id}.wav"
    if not os.path.exists(input_path):
        raise HTTPException(404, "Source audio not found")

    result = models["musicgen"].continue_audio(
        audio_path=input_path,
        extend_duration=extend_duration,
        prompt=prompt
    )

    new_id = str(uuid.uuid4())
    output_path = f"{settings.OUTPUT_DIR}/{new_id}.wav"
    models["audio_processor"].save_audio(result, output_path)

    return {
        "audio_id": new_id,
        "parent_id": audio_id,
        "url": f"/api/v1/audio/{new_id}",
        "extended_duration": extend_duration
    }

@app.post("/api/v1/remix")
async def remix_audio(
    audio_id: str = Form(...),
    style_prompt: str = Form(...),
    intensity: float = Form(default=0.5)
):
    """Remix existing audio with new style."""
    input_path = f"{settings.OUTPUT_DIR}/{audio_id}.wav"
    if not os.path.exists(input_path):
        raise HTTPException(404, "Source audio not found")

    result = models["musicgen"].remix(
        audio_path=input_path,
        style_prompt=style_prompt,
        intensity=intensity
    )

    new_id = str(uuid.uuid4())
    output_path = f"{project_root}/backend/{settings.OUTPUT_DIR}/{new_id}.wav"
    models["audio_processor"].save_audio(result, output_path)

    return {
        "audio_id": new_id,
        "url": f"/api/v1/audio/{new_id}",
        "style": style_prompt
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, workers=1)
