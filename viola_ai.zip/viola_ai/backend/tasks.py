"""
Celery tasks for long-running operations.
Handles music generation, stem separation, and visual effects.
"""

import os
import torch
import torchaudio
from celery import Celery
from datetime import datetime
import redis

from services.music_generator import MusicGenerator
from services.stem_separator import StemSeparator
from services.visual_effects import VisualEffects
from services.audio_processor import AudioProcessor
from utils.config import Settings
from utils.logger import setup_logger

settings = Settings()
logger = setup_logger("celery_tasks")

# Celery app
celery_app = Celery(
    'viola_ai',
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND
)

redis_client = redis.Redis(
    host=settings.REDIS_HOST,
    port=settings.REDIS_PORT,
    decode_responses=True
)

# Initialize models (loaded per worker)
music_gen = None
stem_sep = None
vis_fx = None
audio_proc = None

def init_models():
    """Initialize models on first use."""
    global music_gen, stem_sep, vis_fx, audio_proc

    if music_gen is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        music_gen = MusicGenerator(device=device, model_size="large")
        stem_sep = StemSeparator(device=device, model_name="htdemucs_ft")
        vis_fx = VisualEffects()
        audio_proc = AudioProcessor()

@celery_app.task(bind=True, max_retries=3)
def generate_music(self, job_id: str, request: dict):
    """
    Generate music task (supports up to 5 minutes).
    """
    try:
        init_models()

        # Update status
        redis_client.hset(f"job:{job_id}", mapping={
            "status": "processing",
            "message": "Initializing generation...",
            "progress": 5
        })

        def progress_callback(current, total, message):
            progress = int((current / total) * 90) + 5
            redis_client.hset(f"job:{job_id}", mapping={
                "progress": progress,
                "message": message
            })
            self.update_state(state='PROGRESS', meta={
                'current': current,
                'total': total,
                'message': message
            })

        # Generate
        duration = request.get('duration', 30)
        melody = None
        if request.get('melody_file'):
            melody_path = f"{settings.UPLOAD_DIR}/{request['melody_file']}"
            if os.path.exists(melody_path):
                melody, _ = audio_proc.load_audio(audio_path=melody_path)

        audio = music_gen.generate(
            prompt=request['prompt'],
            duration=duration,
            style_tags=request.get('style_tags', []),
            melody=melody,
            bpm=request.get('bpm'),
            key=request.get('key'),
            cfg_scale=request.get('cfg_scale', 7.0),
            temperature=request.get('temperature', 1.0),
            top_k=request.get('top_k', 250),
            top_p=request.get('top_p', 0.9),
            progress_callback=progress_callback
        )

        # Save
        audio_id = f"gen_{job_id}"
        output_path = f"{settings.OUTPUT_DIR}/{audio_id}.wav"
        audio_proc.save_audio(audio, output_path)

        # Update status
        redis_client.hset(f"job:{job_id}", mapping={
            "status": "completed",
            "progress": 100,
            "message": "Generation complete",
            "result": audio_id,
            "completed_at": datetime.now().isoformat()
        })

        return {
            "audio_id": audio_id,
            "duration": duration,
            "url": f"/api/v1/audio/{audio_id}"
        }

    except Exception as e:
        logger.error(f"Generation failed: {e}")
        redis_client.hset(f"job:{job_id}", mapping={
            "status": "failed",
            "error": str(e),
            "completed_at": datetime.now().isoformat()
        })
        raise self.retry(exc=e, countdown=60)

@celery_app.task(bind=True, max_retries=2)
def separate_stems(self, job_id: str, request: dict):
    """
    Stem separation task.
    """
    try:
        init_models()

        redis_client.hset(f"job:{job_id}", mapping={
            "status": "processing",
            "message": "Loading audio...",
            "progress": 10
        })

        # Load audio
        audio_id = request['audio_id']
        audio_path = f"{settings.UPLOAD_DIR}/{audio_id}"

        if not os.path.exists(audio_path):
            # Try output directory
            audio_path = f"{settings.OUTPUT_DIR}/{audio_id}.wav"

        redis_client.hset(f"job:{job_id}", mapping={
            "message": "Separating stems...",
            "progress": 30
        })

        # Separate
        stems = stem_sep.separate(
            audio_path=audio_path,
            model_name=request.get('model', 'htdemucs_ft'),
            two_stems=request.get('two_stems'),
            segment_length=request.get('segment_length', 7)
        )

        redis_client.hset(f"job:{job_id}", mapping={
            "message": "Saving stems...",
            "progress": 80
        })

        # Save stems
        stem_ids = {}
        for stem_name, stem_audio in stems.items():
            stem_id = f"{audio_id}_{stem_name}"
            output_path = f"{settings.OUTPUT_DIR}/{stem_id}.wav"
            audio_proc.save_audio(stem_audio, output_path)
            stem_ids[stem_name] = stem_id

        redis_client.hset(f"job:{job_id}", mapping={
            "status": "completed",
            "progress": 100,
            "message": "Separation complete",
            "result": stem_ids,
            "completed_at": datetime.now().isoformat()
        })

        return {
            "stems": stem_ids,
            "urls": {k: f"/api/v1/audio/{v}" for k, v in stem_ids.items()}
        }

    except Exception as e:
        logger.error(f"Separation failed: {e}")
        redis_client.hset(f"job:{job_id}", mapping={
            "status": "failed",
            "error": str(e)
        })
        raise self.retry(exc=e, countdown=30)

@celery_app.task(bind=True, max_retries=2)
def clone_voice(self, job_id: str, request: dict):
    """
    Voice cloning task.
    """
    try:
        init_models()

        redis_client.hset(f"job:{job_id}", mapping={
            "status": "processing",
            "message": "Cloning voice...",
            "progress": 20
        })

        # In production: Use RVC for voice cloning
        # Placeholder: Generate synthetic voice
        from services.voice_engine import VoiceEngine
        voice_engine = VoiceEngine()

        voice_sample = f"{settings.UPLOAD_DIR}/{request['voice_sample_id']}"
        audio = voice_engine.clone_voice(
            voice_sample_path=voice_sample,
            text=request['text'],
            emotion=request.get('emotion', 'neutral'),
            speed=request.get('speed', 1.0)
        )

        audio_id = f"voice_{job_id}"
        output_path = f"{settings.OUTPUT_DIR}/{audio_id}.wav"
        audio_proc.save_audio(audio, output_path)

        redis_client.hset(f"job:{job_id}", mapping={
            "status": "completed",
            "progress": 100,
            "result": audio_id
        })

        return {
            "audio_id": audio_id,
            "url": f"/api/v1/audio/{audio_id}"
        }

    except Exception as e:
        logger.error(f"Voice cloning failed: {e}")
        redis_client.hset(f"job:{job_id}", mapping={
            "status": "failed",
            "error": str(e)
        })
        raise self.retry(exc=e, countdown=30)

@celery_app.task(bind=True, max_retries=2)
def generate_visual(self, job_id: str, request: dict):
    """
    Visual effect generation task.
    """
    try:
        init_models()

        redis_client.hset(f"job:{job_id}", mapping={
            "status": "processing",
            "message": "Generating visual effects...",
            "progress": 10
        })

        audio_id = request['audio_id']
        audio_path = f"{settings.OUTPUT_DIR}/{audio_id}.wav"

        if not os.path.exists(audio_path):
            audio_path = f"{settings.UPLOAD_DIR}/{audio_id}"

        redis_client.hset(f"job:{job_id}", mapping={
            "progress": 30,
            "message": "Rendering frames..."
        })

        # Generate visual effect
        video_path = vis_fx.generate(
            audio_path=audio_path,
            effect_type=request['effect_type'],
            resolution=request.get('resolution', '1920x1080'),
            color_scheme=request.get('color_scheme', 'neon'),
            duration=request.get('duration', 30)
        )

        # Move to output directory
        final_path = f"{settings.OUTPUT_DIR}/effect_{job_id}.mp4"
        os.rename(video_path, final_path)

        redis_client.hset(f"job:{job_id}", mapping={
            "status": "completed",
            "progress": 100,
            "message": "Visual effect complete",
            "result": f"effect_{job_id}",
            "completed_at": datetime.now().isoformat()
        })

        return {
            "video_id": f"effect_{job_id}",
            "url": f"/api/v1/video/effect_{job_id}"
        }

    except Exception as e:
        logger.error(f"Visual effect generation failed: {e}")
        redis_client.hset(f"job:{job_id}", mapping={
            "status": "failed",
            "error": str(e)
        })
        raise self.retry(exc=e, countdown=30)
