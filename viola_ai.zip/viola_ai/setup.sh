#!/bin/bash
# Viola AI Setup Script
# Run this to install dependencies and prepare the environment

set -e

echo "🎵 Viola AI Setup"
echo "=================="

# Check Python version
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: $python_version"

# Check CUDA
if command -v nvidia-smi &> /dev/null; then
    echo "✅ CUDA available:"
    nvidia-smi --query-gpu=name,memory.total --format=csv,noheader
else
    echo "⚠️  CUDA not detected. Will use CPU (slower)."
fi

# Create virtual environment
echo ""
echo "Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip setuptools wheel

# Install PyTorch with CUDA
if command -v nvidia-smi &> /dev/null; then
    echo "Installing PyTorch with CUDA support..."
    pip install torch==2.1.0+cu118 torchaudio==2.1.0+cu118         --index-url https://download.pytorch.org/whl/cu118
else
    echo "Installing PyTorch (CPU only)..."
    pip install torch torchaudio
fi

# Install requirements
echo ""
echo "Installing dependencies..."
pip install -r backend/requirements.txt

# Create directories
echo ""
echo "Creating directories..."
mkdir -p outputs uploads models logs

# Download models
echo ""
echo "Downloading AI models..."
python3 -c "
from audiocraft.models import MusicGen
print('Downloading MusicGen models...')
MusicGen.get_pretrained('small')
MusicGen.get_pretrained('medium')
MusicGen.get_pretrained('large')
print('✅ MusicGen models downloaded')
"

python3 -c "
from demucs import pretrained
print('Downloading Demucs models...')
pretrained.get_model('htdemucs')
pretrained.get_model('htdemucs_ft')
print('✅ Demucs models downloaded')
"

# Setup frontend
echo ""
echo "Setting up frontend..."
cd frontend
npm install
cd ..

# Create .env file
echo ""
echo "Creating environment file..."
cat > .env << EOF
# Viola AI Configuration
HOST=0.0.0.0
PORT=8000
DEBUG=false
OUTPUT_DIR=./outputs
UPLOAD_DIR=./uploads
MODEL_DIR=./models
REDIS_HOST=localhost
REDIS_PORT=6379
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0
CUDA_VISIBLE_DEVICES=0
EOF

echo ""
echo "✅ Setup complete!"
echo ""
echo "To start Viola AI:"
echo "  1. Start Redis: redis-server"
echo "  2. Start Celery: celery -A backend.tasks worker --loglevel=info"
echo "  3. Start API: cd backend && python main.py"
echo "  4. Start Frontend: cd frontend && npm start"
echo ""
echo "Or use Docker: docker-compose up -d"
